import express from "express";
import pool from "../db.js";
import { getTransferKpiHistory } from "./summary.js";
import { log } from "console";
import pLimit from "p-limit";
const bmCalculationCache = new Map();
const insuranceCache = new Map();

setInterval(() => {
  bmCalculationCache.clear();
  insuranceCache.clear();
}, 600000);

export const performanceMasterRouter = express.Router();
//get kpi role wise
performanceMasterRouter.post("/getKpiRoleWise", (req, res) => {
  const { role } = req.body;

  if (!role) {
    return res.status(400).json({ error: "Role is required" });
  }

  pool.getConnection((err, connection) => {
    if (err) {
      console.error("Connection error:", err);
      return res.status(500).json({ error: "Internal server error" });
    }

    const query = `
      SELECT r.id,k.kpi_name  FROM role_kpi_mapping r join kpi_master k on r.kpi_id = k.id WHERE role = ?
    `;

    connection.query(query, [role], (error, results) => {
      connection.release();

      if (error) {
        console.error("Query error:", error);
        return res.status(500).json({ error: "Database fetch failed" });
      }

      if (results.length === 0) {
        return res.status(404).json({ message: "No KPI found for this role" });
      }

      res.json({
        message: "KPI fetched successfully",
        data: results,
      });
    });
  });
});

//get specific staff data // change for transfer logic and optimized // 23-02-2026
performanceMasterRouter.get("/specfic-ALLstaff-scores", async (req, res) => {
  const { period, ho_staff_id, role, hod_id } = req.query;

  if (!period || !ho_staff_id || !role) {
    return res
      .status(400)
      .json({ error: "period, ho_staff_id, and role are required" });
  }

  try {
    const kpiWeightage = await new Promise((resolve, reject) => {
      pool.query(
        `
        SELECT 
          rkm.id AS role_kpi_mapping_id,
          km.kpi_name,
          rkm.weightage
        FROM role_kpi_mapping rkm
        JOIN kpi_master km ON km.id = rkm.kpi_id
        WHERE rkm.role = ? AND rkm.deleted_at IS NULL
        `,
        [role],
        (err, rows) => (err ? reject(err) : resolve(rows)),
      );
    });

    if (!kpiWeightage.length) {
      return res.status(404).json({ error: "No KPI found for this role" });
    }

    const [userEntries, insuranceRows] = await Promise.all([
      new Promise((resolve, reject) => {
        pool.query(
          `
          SELECT role_kpi_mapping_id, value AS achieved
          FROM user_kpi_entry
          WHERE period = ?
          AND user_id = ?
          AND deleted_at IS NULL
          AND master_user_id = ?
          `,
          [period, ho_staff_id, hod_id],
          (err, rows) => (err ? reject(err) : resolve(rows)),
        );
      }),

      new Promise((resolve, reject) => {
        pool.query(
          `
          SELECT value AS achieved
          FROM entries
          WHERE kpi='insurance' AND employee_id = ?
          `,
          [ho_staff_id],
          (err, rows) => (err ? reject(err) : resolve(rows)),
        );
      }),
    ]);

    const insuranceValue = insuranceRows.length
      ? Number(insuranceRows[0].achieved)
      : 0;

    const achievedMap = {};
    userEntries.forEach((e) => {
      achievedMap[e.role_kpi_mapping_id] = e.achieved;
    });

    let totalWeightageScore = 0;
    const scores = {};

    for (const row of kpiWeightage) {
      const { role_kpi_mapping_id, kpi_name, weightage } = row;

      let achieved = 0;

      if (kpi_name.toLowerCase() === "insurance") {
        achieved = insuranceValue;
      } else {
        achieved = parseFloat(achievedMap[role_kpi_mapping_id]) || 0;
      }

      const target = kpi_name.toLowerCase() === "insurance" ? 40000 : weightage;

      let score = 0;
      if (achieved > 0) {
        if (kpi_name.toLowerCase() === "insurance") {
          const ratio = achieved / target;
          if (ratio <= 1) score = ratio * 10;
          else if (ratio < 1.25) score = 10;
          else score = 12.5;
        } else {
          const ratio = achieved / target;
          if (ratio <= 1) score = ratio * 10;
          else if (ratio < 1.25) score = 10;
          else score = 12.5;
        }
      }

      let weightageScore = (score * weightage) / 100;

      totalWeightageScore += weightageScore;

      scores[kpi_name] = {
        score: Number(score.toFixed(2)),
        achieved,
        weightage,
        weightageScore: Number(weightageScore.toFixed(2)),
      };
    }

    const currentTotal = Number(totalWeightageScore.toFixed(2));

    const [hoHistory, attHistory, transferHistory] = await Promise.all([
      new Promise((resolve) => {
        getHoStaffTransferHistory(pool, period, ho_staff_id, (err, data) =>
          resolve(err ? [] : data),
        );
      }),

      new Promise((resolve) => {
        getAttenderTransferHistory(pool, period, ho_staff_id, (err, data) =>
          resolve(err ? [] : data),
        );
      }),

      getTransferKpiHistory(pool, period, ho_staff_id),
    ]);

    const previousHoScores =
      hoHistory?.[0]?.transfers?.map((t) => Number(t.total_weightage_score)) ||
      [];

    const previousAttenderScores =
      attHistory?.[0]?.transfers?.map((t) => Number(t.total_weightage_score)) ||
      [];

    const previousTransferScores =
      transferHistory?.all_scores?.map(Number) || [];

    const allScores = [
      ...previousHoScores,
      ...previousAttenderScores,
      ...previousTransferScores,
      currentTotal,
    ];

    const finalAvg =
      allScores.length > 0
        ? allScores.reduce((a, b) => a + b, 0) / allScores.length
        : 0;
    scores.originalTotal = Number(totalWeightageScore.toFixed(2));
    scores.total = Number(finalAvg.toFixed(2));

    return res.json(scores);
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      error: "Failed to fetch staff scores",
    });
  }
});
//function to get single - single staff score calculation
const kpiWeightageCache = new Map();

async function calculateStaffScores(period, staffId, role) {
  try {
    // CACHE KPI WEIGHTAGE
    let kpiWeightage = kpiWeightageCache.get(role);

    if (!kpiWeightage) {
      kpiWeightage = await new Promise((resolve, reject) => {
        pool.query(
          `
              SELECT 
                rkm.id AS role_kpi_mapping_id,
                km.kpi_name,
                rkm.weightage
              FROM role_kpi_mapping rkm
              JOIN kpi_master km
                ON km.id = rkm.kpi_id
              WHERE rkm.role = ?
              AND rkm.deleted_at IS NULL
              `,
          [role],
          (err, rows) => {
            if (err) {
              return reject(err);
            }

            resolve(rows);
          },
        );
      });

      kpiWeightageCache.set(role, kpiWeightage);
    }

    // PARALLEL QUERIES
    const [userEntries, allInsuranceEntries] = await Promise.all([
      new Promise((resolve, reject) => {
        pool.query(
          `
          SELECT 
            role_kpi_mapping_id,
            value AS achieved
          FROM user_kpi_entry
          WHERE period = ?
          AND user_id = ?
          AND deleted_at IS NULL
          `,
          [period, staffId],
          (err, rows) => {
            if (err) {
              return reject(err);
            }

            resolve(rows);
          },
        );
      }),

      new Promise((resolve) => {
        pool.query(
          `
          SELECT 
            value AS achieved
          FROM entries
          WHERE kpi = 'insurance'
          AND employee_id = ?
          `,
          [staffId],
          (err, rows) => {
            resolve(rows || []);
          },
        );
      }),
    ]);

    const achievedMap = {};

    // FIND INSURANCE KPI ONCE
    let insuranceKpi = null;

    for (const k of kpiWeightage) {
      if (k.kpi_name.toLowerCase() === "insurance") {
        insuranceKpi = k;
        break;
      }
    }

    // FAST MAP
    for (const e of userEntries) {
      achievedMap[e.role_kpi_mapping_id] = Number(e.achieved || 0);
    }

    // INSURANCE MAP
    if (insuranceKpi) {
      let insuranceTotal = 0;

      for (const e of allInsuranceEntries) {
        insuranceTotal += Number(e.achieved || 0);
      }

      achievedMap[insuranceKpi.role_kpi_mapping_id] = insuranceTotal;
    }

    let totalWeightageScore = 0;

    const scores = {};

    for (const row of kpiWeightage) {
      const { role_kpi_mapping_id, kpi_name, weightage } = row;

      const achieved = achievedMap[role_kpi_mapping_id] || 0;

      const isInsurance = kpi_name.toLowerCase() === "insurance";

      const target = isInsurance ? 40000 : weightage;

      let score = 0;

      if (achieved > 0) {
        const ratio = achieved / target;

        if (ratio <= 1) {
          score = ratio * 10;
        } else if (ratio < 1.25) {
          score = 10;
        } else {
          score = 12.5;
        }
      }

      let weightageScore = (score * weightage) / 100;

      totalWeightageScore += weightageScore;

      scores[kpi_name] = {
        score: Number(score.toFixed(2)),

        achieved,

        weightage,

        weightageScore: Number(weightageScore.toFixed(2)),
      };
    }

    scores.total = Number(totalWeightageScore.toFixed(2));

    return scores;
  } catch (err) {
    throw err;
  }
}

// function to get batch staff score calculation
async function calculateStaffScoresBatch(period, staffIds, role) {
  try {
    if (!staffIds || staffIds.length === 0) {
      return {};
    }

    // CACHE KPI WEIGHTAGE
    let kpiWeightage = kpiWeightageCache.get(role);

    if (!kpiWeightage) {
      kpiWeightage = await new Promise((resolve, reject) => {
        pool.query(
          `
              SELECT 
                rkm.id AS role_kpi_mapping_id,
                km.kpi_name,
                rkm.weightage
              FROM role_kpi_mapping rkm
              JOIN kpi_master km
                ON km.id = rkm.kpi_id
              WHERE rkm.role = ?
              AND rkm.deleted_at IS NULL
              `,
          [role],
          (err, rows) => {
            if (err) {
              return reject(err);
            }

            resolve(rows);
          },
        );
      });

      kpiWeightageCache.set(role, kpiWeightage);
    }

    // PARALLEL QUERIES
    const [userEntries, allInsuranceEntries] = await Promise.all([
      new Promise((resolve, reject) => {
        pool.query(
          `
          SELECT 
            user_id,
            role_kpi_mapping_id,
            value AS achieved
          FROM user_kpi_entry
          WHERE period = ?
          AND user_id IN (?)
          AND deleted_at IS NULL
          `,
          [period, staffIds],
          (err, rows) => {
            if (err) {
              return reject(err);
            }

            resolve(rows || []);
          },
        );
      }),

      new Promise((resolve) => {
        pool.query(
          `
          SELECT 
            employee_id,
            value AS achieved
          FROM entries
          WHERE kpi = 'insurance'
          AND employee_id IN (?)
          `,
          [staffIds],
          (err, rows) => {
            resolve(rows || []);
          },
        );
      }),
    ]);

    const staffUserEntriesMap = {};
    const staffInsuranceEntriesMap = {};

    for (const id of staffIds) {
      staffUserEntriesMap[id] = [];
      staffInsuranceEntriesMap[id] = [];
    }

    for (const e of userEntries) {
      if (staffUserEntriesMap[e.user_id]) {
        staffUserEntriesMap[e.user_id].push(e);
      }
    }

    for (const e of allInsuranceEntries) {
      if (staffInsuranceEntriesMap[e.employee_id]) {
        staffInsuranceEntriesMap[e.employee_id].push(e);
      }
    }

    const batchScores = {};

    // FIND INSURANCE KPI ONCE
    let insuranceKpi = null;

    for (const k of kpiWeightage) {
      if (k.kpi_name.toLowerCase() === "insurance") {
        insuranceKpi = k;
        break;
      }
    }

    for (const staffId of staffIds) {
      const achievedMap = {};
      const uEntries = staffUserEntriesMap[staffId] || [];
      const insEntries = staffInsuranceEntriesMap[staffId] || [];

      // FAST MAP
      for (const e of uEntries) {
        achievedMap[e.role_kpi_mapping_id] = Number(e.achieved || 0);
      }

      // INSURANCE MAP
      if (insuranceKpi) {
        let insuranceTotal = 0;

        for (const e of insEntries) {
          insuranceTotal += Number(e.achieved || 0);
        }

        achievedMap[insuranceKpi.role_kpi_mapping_id] = insuranceTotal;
      }

      let totalWeightageScore = 0;

      const scores = {};

      for (const row of kpiWeightage) {
        const { role_kpi_mapping_id, kpi_name, weightage } = row;

        const achieved = achievedMap[role_kpi_mapping_id] || 0;

        const isInsurance = kpi_name.toLowerCase() === "insurance";

        const target = isInsurance ? 40000 : weightage;

        let score = 0;

        if (achieved > 0) {
          const ratio = achieved / target;

          if (ratio <= 1) {
            score = ratio * 10;
          } else if (ratio < 1.25) {
            score = 10;
          } else {
            score = 12.5;
          }
        }

        let weightageScore = (score * weightage) / 100;

        totalWeightageScore += weightageScore;

        scores[kpi_name] = {
          score: Number(score.toFixed(2)),

          achieved,

          weightage,

          weightageScore: Number(weightageScore.toFixed(2)),
        };
      }

      scores.total = Number(totalWeightageScore.toFixed(2));
      batchScores[staffId] = scores;
    }

    return batchScores;
  } catch (err) {
    throw err;
  }
}

// function to get single BM score calculation
async function calculateBMScores(period, branchId = null) {
  try {
    const cacheKey = `${period}_${branchId || "ALL"}`;

    if (bmCalculationCache.has(cacheKey)) {
      return bmCalculationCache.get(cacheKey);
    }

    const results = await new Promise((resolve, reject) => {
      const query = `
        SELECT
            bm.branch_id,

            k.kpi,

            MAX(
                CASE 
                    WHEN k.kpi = 'audit'
                        THEN 100

                    WHEN k.kpi = 'insurance'
                        THEN COALESCE(a.amount,0)

                    ELSE COALESCE(t.amount,0)
                END
            ) AS target,

            MAX(COALESCE(w.weightage,0))
                AS weightage,

            CASE 
                WHEN k.kpi IN ('deposit', 'loan_gen', 'loan_amulya') 
                    THEN MAX(COALESCE(e.total_achieved, 0)) + MAX(COALESCE(p.amount, 0))
                ELSE MAX(COALESCE(e.total_achieved, 0))
            END AS achieved,
            CASE 
                WHEN k.kpi IN ('deposit', 'loan_gen', 'loan_amulya') 
                    THEN MAX(COALESCE(p.amount, 0))
                ELSE 0
            END AS baseline

        FROM users bm

        CROSS JOIN
        (
            SELECT 'deposit' AS kpi
            UNION ALL
            SELECT 'loan_gen'
            UNION ALL
            SELECT 'loan_amulya'
            UNION ALL
            SELECT 'recovery'
            UNION ALL
            SELECT 'audit'
            UNION ALL
            SELECT 'insurance'
        ) k

        LEFT JOIN targets t
            ON t.kpi COLLATE utf8mb4_unicode_ci = k.kpi COLLATE utf8mb4_unicode_ci
            AND t.period = ?
            AND t.branch_id COLLATE utf8mb4_unicode_ci = bm.branch_id COLLATE utf8mb4_unicode_ci

        LEFT JOIN previous_period_data p
            ON p.kpi COLLATE utf8mb4_unicode_ci = k.kpi COLLATE utf8mb4_unicode_ci
            AND p.period = ?
            AND p.branch_id COLLATE utf8mb4_unicode_ci = bm.branch_id COLLATE utf8mb4_unicode_ci

        LEFT JOIN allocations a
            ON k.kpi COLLATE utf8mb4_unicode_ci = 'insurance' COLLATE utf8mb4_unicode_ci
            AND a.user_id COLLATE utf8mb4_unicode_ci = bm.id COLLATE utf8mb4_unicode_ci
            AND a.period = ?

        LEFT JOIN weightage w
            ON w.kpi COLLATE utf8mb4_unicode_ci = k.kpi COLLATE utf8mb4_unicode_ci

        LEFT JOIN
        (
            SELECT
                x.branch_id,
                x.kpi,
                SUM(x.value)
                    AS total_achieved

            FROM
            (

                SELECT
                    u.branch_id,
                    e.kpi,
                    e.value

                FROM entries e

                INNER JOIN users u
                    ON u.id COLLATE utf8mb4_unicode_ci = e.employee_id COLLATE utf8mb4_unicode_ci
                    AND u.role = 'BM'
                    AND u.resign = 0
                    AND u.period = ?

                WHERE
                    e.period = ?
                    AND e.status = 'Verified'
                    AND e.kpi IN (
                        'audit',
                        'recovery',
                        'insurance'
                    )

                UNION ALL

                SELECT
                    e.branch_id,
                    e.kpi,
                    e.value

                FROM entries e

                WHERE
                    e.period = ?
                    AND e.status = 'Verified'
                    AND e.kpi NOT IN (
                        'audit',
                        'recovery',
                        'insurance'
                    )

            ) x

            GROUP BY
                x.branch_id,
                x.kpi

        ) e
            ON e.branch_id COLLATE utf8mb4_unicode_ci = bm.branch_id COLLATE utf8mb4_unicode_ci
            AND e.kpi COLLATE utf8mb4_unicode_ci = k.kpi COLLATE utf8mb4_unicode_ci

        WHERE
            bm.role = 'BM'
            AND bm.resign = 0
            AND bm.period = ?
            ${branchId ? "AND bm.branch_id = ?" : ""}

        GROUP BY
            bm.branch_id,
            k.kpi

        ORDER BY
            bm.branch_id,
            k.kpi
        `;

      const params = [period, period, period, period, period, period, period];

      if (branchId) {
        params.push(branchId);
      }

      pool.query(
        query,
        params,

        (err, rows) => {
          if (err) {
            return reject(err);
          }

          resolve(rows || []);
        },
      );
    });

    const grouped = {};

    for (const row of results) {
      if (!grouped[row.branch_id]) {
        grouped[row.branch_id] = [];
      }

      grouped[row.branch_id].push(row);
    }

    const finalResponse = {};

    for (const branch in grouped) {
      const branchRows = grouped[branch];

      let auditRatio = 0;
      let recoveryRatio = 0;

      for (const row of branchRows) {
        const prevBal = Number(row.baseline) || 0;
        const targetN = Number(row.target) || 0;
        const currentAch = Number(row.achieved) || 0;
        const ratioVal = targetN > 0 ? Math.max(0, (currentAch - prevBal) / targetN) : 0;
        if (row.kpi === "audit") {
          auditRatio = ratioVal;
        }
        if (row.kpi === "recovery") {
          recoveryRatio = ratioVal;
        }
      }

      const calculateScores = (cap) => {
        const scores = {};

        let totalWeightageScore = 0;

        for (const row of branchRows) {
          const previousBalance = Number(row.baseline) || 0;
          const newTarget = Number(row.target) || 0;
          const totalTarget = previousBalance + newTarget;
          const currentAchieved = Number(row.achieved) || 0;
          const weightage = Number(row.weightage) || 0;

          const isBaselineOnly = previousBalance > 0 && currentAchieved <= previousBalance;
          let outOf10 = 0;
          let ratio = 0;

          if (!isBaselineOnly) {
            ratio = newTarget > 0 ? Math.max(0, (currentAchieved - previousBalance) / newTarget) : 0;

            switch (row.kpi) {
              case "deposit":
              case "loan_gen":
              case "loan_amulya":
                if (ratio <= 1) {
                  outOf10 = ratio * 10;
                } else if (ratio < 1.25) {
                  outOf10 = 10;
                } else if (auditRatio >= 0.75 && recoveryRatio >= 0.75) {
                  outOf10 = 12.5;
                } else {
                  outOf10 = 10;
                }

                break;

              case "insurance":
                if (ratio <= 0 || isNaN(ratio)) {
                  outOf10 = 0;
                } else if (ratio <= 1) {
                  outOf10 = ratio * 10;
                } else if (ratio < 1.25) {
                  outOf10 = 10;
                } else {
                  outOf10 = 12.5;
                }

                break;

              case "recovery":
              case "audit":
                if (ratio <= 0 || isNaN(ratio)) {
                  outOf10 = 0;
                } else if (ratio <= 1) {
                  outOf10 = ratio * 10;
                } else {
                  outOf10 = 12.5;
                }

                break;
            }

            if (outOf10 > cap) {
              outOf10 = cap;
            } else if (outOf10 < 0 || isNaN(outOf10)) {
              outOf10 = 0;
            }
          }

          const weightageScore = isBaselineOnly
            ? 0
            : (outOf10 * weightage) / 100;

          scores[row.kpi] = {
            score: outOf10,
            previousBalance,
            newTarget,
            totalTarget,
            target: totalTarget, // for backward compatibility with UI
            achieved: isBaselineOnly ? 0 : currentAchieved,
            weightage,
            weightageScore,
          };

          totalWeightageScore += weightageScore;
        }

        scores.total = totalWeightageScore;

        return scores;
      };

      const preliminaryScores = calculateScores(12.5);

      const insuranceScore = preliminaryScores.insurance?.score || 0;

      const recoveryScore = preliminaryScores.recovery?.score || 0;

      const cap =
        preliminaryScores.total > 10 &&
          insuranceScore < 7.5 &&
          recoveryScore < 7.5
          ? 10
          : 12.5;

      finalResponse[branch] = calculateScores(cap);
    }

    bmCalculationCache.set(cacheKey, finalResponse);

    return branchId ? finalResponse[branchId] : finalResponse;
  } catch (err) {
    throw err;
  }
}

async function calculateBMScoresFortrasfer(period, branchId) {
  try {
    const results = await new Promise((resolve, reject) => {
      const query = `
       SELECT
        k.kpi,
        CASE 
            WHEN k.kpi = 'audit' THEN 100
            WHEN k.kpi = 'insurance' THEN COALESCE(a.amount,0)
            ELSE t.amount
        END AS target,
        w.weightage,
        CASE 
            WHEN k.kpi IN ('deposit', 'loan_gen', 'loan_amulya') 
                THEN COALESCE(e.total_achieved, 0) + COALESCE(p.amount, 0)
            ELSE COALESCE(e.total_achieved, 0)
        END AS achieved,
        CASE 
            WHEN k.kpi IN ('deposit', 'loan_gen', 'loan_amulya') 
                THEN COALESCE(p.amount, 0)
            ELSE 0
        END AS baseline
      FROM
      (
          SELECT 'deposit' AS kpi UNION ALL
          SELECT 'loan_gen' UNION ALL
          SELECT 'loan_amulya' UNION ALL
          SELECT 'recovery' UNION ALL
          SELECT 'audit' UNION ALL
          SELECT 'insurance'
      ) k
      LEFT JOIN users bm
        ON bm.branch_id = ?
        AND bm.role = 'BM'
        AND bm.resign = 0
        AND bm.period = ?
      LEFT JOIN targets t
        ON t.kpi = k.kpi
        AND t.period = ?
        AND t.branch_id = ?
      LEFT JOIN previous_period_data p
        ON p.kpi = k.kpi
        AND p.period = ?
        AND p.branch_id = ?
      LEFT JOIN allocations a
        ON k.kpi = 'insurance'
        AND a.user_id = bm.id
        AND a.period = ?
      LEFT JOIN weightage w
        ON w.kpi = k.kpi
      LEFT JOIN (
          SELECT
              e.kpi,
              SUM(e.value) AS total_achieved
          FROM entries e
          LEFT JOIN users bm
              ON bm.branch_id = ?
              AND bm.role = 'BM'
              AND bm.resign = 0
              AND bm.period = ?
          WHERE
              e.period = ?
              AND e.status = 'Verified'
              AND (
                  (e.kpi IN ('insurance','audit','recovery') AND e.employee_id = bm.id)
                  OR
                  (e.kpi NOT IN ('audit','recovery','insurance') AND e.branch_id = ?)
              )
          GROUP BY e.kpi
      ) e
      ON k.kpi = e.kpi;
      `;

      pool.query(
        query,
        [
          branchId,
          period,
          period,
          branchId,
          period,
          branchId,
          period,
          branchId,
          period,
          period,
          branchId,
        ],
        (err, rows) => {
          if (err) return reject(err);
          resolve(rows);
        },
      );
    });

    const [bmRow, insuranceRow] = await Promise.all([
      new Promise((resolve, reject) => {
        pool.query(
          `SELECT id FROM users WHERE branch_id=? AND period=? AND role='BM' LIMIT 1`,
          [branchId, period],
          (err, rows) => {
            if (err) return reject(err);
            resolve(rows?.[0]?.id || 0);
          },
        );
      }),

      new Promise((resolve, reject) => {
        pool.query(
          `
          SELECT SUM(value) AS achieved
          FROM entries
          WHERE period=? AND kpi='insurance'
            AND employee_id = (
              SELECT id FROM users WHERE branch_id=? AND period=? AND role='BM' LIMIT 1
            )
          `,
          [period, branchId, period],
          (err, rows) => {
            if (err) return reject(err);
            resolve(rows?.[0]?.achieved || 0);
          },
        );
      }),
    ]);

    // update insurance achieved
    results.forEach((row) => {
      if (row.kpi === "insurance") {
        row.achieved = insuranceRow;
      }
    });

    const bmKpis = [
      "deposit",
      "loan_gen",
      "loan_amulya",
      "recovery",
      "audit",
      "insurance",
    ];

    const calculateScores = (cap) => {
      const scores = {};
      let totalWeightageScore = 0;

      bmKpis.forEach((kpi) => {
        scores[kpi] = {
          score: 0,
          target: 0,
          achieved: 0,
          weightage: 0,
          weightageScore: 0,
        };
      });

      const auditRow = results.find((r) => r.kpi === "audit");
      const recoveryRow = results.find((r) => r.kpi === "recovery");

      const getRatioVal = (row) => {
        if (!row) return 0;
        const prevBal = Number(row.baseline) || 0;
        const targetN = Number(row.target) || 0;
        const currentAch = Number(row.achieved) || 0;
        return targetN > 0 ? Math.max(0, (currentAch - prevBal) / targetN) : 0;
      };

      const auditRatio = getRatioVal(auditRow);
      const recoveryRatio = getRatioVal(recoveryRow);

      results.forEach((row) => {
        if (!bmKpis.includes(row.kpi)) return;

        const previousBalance = Number(row.baseline) || 0;
        const newTarget = Number(row.target) || 0;
        const totalTarget = previousBalance + newTarget;
        const currentAchieved = Number(row.achieved) || 0;

        const isBaselineOnly =
          previousBalance > 0 && currentAchieved <= previousBalance;
        let outOf10 = 0;
        const weightage = row.weightage || 0;

        if (!newTarget) {
          scores[row.kpi] = {
            score: 0,
            previousBalance,
            newTarget,
            totalTarget,
            target: totalTarget,
            achieved: isBaselineOnly ? 0 : currentAchieved,
            weightage,
            weightageScore: 0,
          };
          return;
        }

        let ratio = 0;

        if (!isBaselineOnly) {
          ratio = newTarget > 0 ? Math.max(0, (currentAchieved - previousBalance) / newTarget) : 0;

          switch (row.kpi) {
            case "deposit":
            case "loan_gen":
            case "loan_amulya":
              if (ratio <= 1) outOf10 = ratio * 10;
              else if (ratio < 1.25) outOf10 = 10;
              else if (auditRatio >= 0.75 && recoveryRatio >= 0.75)
                outOf10 = 12.5;
              else outOf10 = 10;
              break;

            case "insurance":
              if (ratio === 0) outOf10 = 0;
              else if (ratio <= 1) outOf10 = ratio * 10;
              else if (ratio < 1.25) outOf10 = 10;
              else outOf10 = 12.5;
              break;

            case "recovery":
            case "audit":
              if (ratio <= 1) outOf10 = ratio * 10;
              else outOf10 = 12.5;
              break;
          }

          outOf10 = Math.max(0, Math.min(cap, isNaN(outOf10) ? 0 : outOf10));
        }

        const weightageScore = isBaselineOnly
          ? 0
          : (outOf10 * weightage) / 100;

        scores[row.kpi] = {
          score: outOf10,
          previousBalance,
          newTarget,
          totalTarget,
          target: totalTarget,
          achieved: isBaselineOnly ? 0 : currentAchieved,
          weightage,
          weightageScore,
        };

        totalWeightageScore += weightageScore;
      });

      scores.total = totalWeightageScore;
      return scores;
    };

    const preliminaryScores = calculateScores(12.5);
    const insuranceScore = preliminaryScores.insurance?.score || 0;
    const recoveryScore = preliminaryScores.recovery?.score || 0;

    const cap =
      preliminaryScores.total > 10 &&
        insuranceScore < 7.5 &&
        recoveryScore < 7.5
        ? 10
        : 12.5;

    const finalScores = calculateScores(cap);

    return finalScores;
  } catch (err) {
    throw err;
  }
}
// function to get all hod scores
const scoreCache = new Map();
const branchScoreCache = new Map();
performanceMasterRouter.get("/ho-Allhod-scores", async (req, res) => {
  const { period, hod_id, role } = req.query;

  if (!period || !hod_id) {
    return res.status(400).json({
      error: "period and hod_id are required",
    });
  }

  try {
    const [hodKpis, staffIdsRows, branchCodesRows] = await Promise.all([
      new Promise((resolve, reject) => {
        pool.query(
          `
              SELECT 
                k.kpi_name,
                r.id AS role_kpi_mapping_id,
                r.weightage

              FROM role_kpi_mapping r

              JOIN kpi_master k
                ON r.kpi_id = k.id

              WHERE r.role = ?
              `,

          [role],

          (err, rows) => {
            if (err) {
              return reject(err);
            }

            if (!rows.length) {
              return reject("No KPIs found");
            }

            resolve(rows);
          },
        );
      }),

      new Promise((resolve, reject) => {
        pool.query(
          `
              SELECT id

              FROM users

              WHERE hod_id = ?
              AND period = ?
              `,

          [hod_id, period],

          (err, rows) => {
            if (err) {
              return reject(err);
            }

            resolve(rows);
          },
        );
      }),

      new Promise((resolve, reject) => {
        pool.query(
          `
              SELECT code

              FROM branches

              WHERE incharge_id = ?
              AND period = ?
              `,

          [hod_id, period],

          (err, rows) => {
            if (err) {
              return reject(err);
            }

            resolve(rows);
          },
        );
      }),
    ]);

    const staffIds = staffIdsRows.map((r) => r.id);

    const branchCodes = branchCodesRows.map((r) => r.code);

    const batchSize = 5;

    const staffScores = [];

    for (let i = 0; i < staffIds.length; i += batchSize) {
      const batch = staffIds.slice(i, i + batchSize);

      for (const id of batch) {
        try {
          const cacheKey = `${period}_${id}`;

          if (scoreCache.has(cacheKey)) {
            staffScores.push(scoreCache.get(cacheKey));

            continue;
          }

          const score = await calculateStaffScores(period, id, "HO_STAFF");

          scoreCache.set(cacheKey, score);

          staffScores.push(score);
        } catch {
          staffScores.push({
            total: 0,
          });
        }
      }
    }

    let fixedAvgTotal = 0;

    for (const v of staffScores) {
      fixedAvgTotal += v.total || 0;
    }

    const fixedAvg = Number(
      (fixedAvgTotal / (staffScores.length || 1)).toFixed(2),
    );

    const allBranchScores = await calculateBMScores(period);

    const branchTotals = [];

    for (let i = 0; i < branchCodes.length; i += batchSize) {
      const batch = branchCodes.slice(i, i + batchSize);

      for (const code of batch) {
        try {
          const cacheKey = `${period}_${code}`;

          if (branchScoreCache.has(cacheKey)) {
            branchTotals.push(branchScoreCache.get(cacheKey));

            continue;
          }

          const total = Number(
            (allBranchScores?.[code]?.total || 0).toFixed(2),
          );

          branchScoreCache.set(cacheKey, total);

          branchTotals.push(total);
        } catch {
          branchTotals.push(0);
        }
      }
    }

    let branchTotalValue = 0;

    for (const v of branchTotals) {
      branchTotalValue += v;
    }

    const branchAvgScore = Number(
      (branchTotalValue / (branchTotals.length || 1)).toFixed(2),
    );

    const kpiMap = {};

    for (const k of hodKpis) {
      kpiMap[k.kpi_name] = {
        id: k.role_kpi_mapping_id,

        weightage: k.weightage,
      };
    }

    const [userKpiValues, insuranceValue] = await Promise.all([
      new Promise((resolve, reject) => {
        pool.query(
          `
              SELECT 
                role_kpi_mapping_id,
                SUM(value) AS total

              FROM user_kpi_entry

              WHERE user_id=?
              AND period=?

              GROUP BY role_kpi_mapping_id
              `,

          [hod_id, period],

          (err, rows) => {
            if (err) {
              return reject(err);
            }

            const map = {};

            for (const r of rows) {
              map[r.role_kpi_mapping_id] = Number(r.total || 0);
            }

            resolve(map);
          },
        );
      }),

      new Promise((resolve, reject) => {
        if (!Object.keys(kpiMap).some((k) => k.toLowerCase() === "insurance")) {
          return resolve(0);
        }

        pool.query(
          `
              SELECT 
                SUM(value) AS total

              FROM entries

              WHERE kpi='insurance'
              AND employee_id=?
              AND period=?
              `,

          [hod_id, period],

          (err, rows) => {
            if (err) {
              return reject(err);
            }

            resolve(Number(rows[0]?.total || 0));
          },
        );
      }),
    ]);

    const getVal = (name) => userKpiValues[kpiMap[name]?.id] || 0;

    const Cleanliness = getVal("HO Building Cleanliness");

    const Management = getVal("Management  Discretion");

    const InternalAudit = getVal("Internal Audit performance");

    const IT = getVal("IT");

    const InsuranceBusinessDevelopment = getVal(
      "Insurance Business Development",
    );

    let finalKpis = {};

    let Total = 0;

    for (const kpi of hodKpis) {
      const name = kpi.kpi_name;

      const weightage = kpi.weightage;

      const lowerName = name.toLowerCase();

      let avg = 0;
      let result = 0;
      let weightageScore = 0;
      let rangeCovert = 0;

      if (lowerName.includes("section")) {
        avg = fixedAvg;
      } else if (lowerName.includes("branch") || lowerName.includes("visits")) {
        avg = branchAvgScore;
      } else if (lowerName.includes("clean")) {
        avg = Cleanliness;
      } else if (lowerName.includes("management")) {
        avg = Management;
      } else if (lowerName.includes("audit")) {
        avg = InternalAudit;
      } else if (lowerName.includes("it")) {
        avg = IT;
      } else if (lowerName.includes("insurance business development")) {
        avg = InsuranceBusinessDevelopment;
      }

      rangeCovert = (avg / 10) * weightage;

      if (lowerName === "insurance") {
        const target = 40000;

        avg = insuranceValue;

        if (avg <= target) {
          result = (avg / target) * 10;
        } else if (avg / target < 1.25) {
          result = 10;
        }

        weightageScore = (result / 100) * weightage;
      } else if (
        lowerName.includes("section") ||
        lowerName.includes("branch") ||
        lowerName.includes("visits")
      ) {
        if (rangeCovert === 0) {
          result = 0;
        } else if (rangeCovert <= weightage) {
          result = (rangeCovert / weightage) * 10;
        } else if (rangeCovert / weightage < 1.25) {
          result = 12.5;
        } else {
          result = 0;
        }

        weightageScore = (result / 100) * weightage;
      } else {
        if (avg === 0) {
          result = 0;
        } else if (avg <= weightage) {
          result = (avg / weightage) * 10;
        } else if (avg / weightage < 1.25) {
          result = 12.5;
        } else {
          result = 0;
        }

        weightageScore = (result / 100) * weightage;
      }

      Total += weightageScore;

      finalKpis[name] = {
        score: Number(result.toFixed(2)),

        achieved:
          lowerName.includes("section") ||
            lowerName.includes("branch") ||
            lowerName.includes("visits")
            ? Number(rangeCovert.toFixed(2))
            : avg || 0,

        weightage,

        weightageScore: Number(weightageScore.toFixed(2)),
      };
    }

    res.json({
      hod_id,

      period,

      kpis: finalKpis,

      total: Number(Total.toFixed(2)),
    });
  } catch (err) {
    console.error(err);

    res.status(500).json({
      error: "Failed to calculate HOD scores",
    });
  }
});

//all HO_STAFF kpis /// change for transfer logic and optimized // 23-02-2026
performanceMasterRouter.get("/ho-staff-scores-all", async (req, res) => {
  const { period, hod_id, role } = req.query;

  if (!period || !hod_id || !role) {
    return res.status(400).json({
      error: "period, hod_id, and role required",
    });
  }

  try {
    const kpiList = await new Promise((resolve, reject) => {
      pool.query(
        `
        SELECT 
          rkm.id AS role_kpi_mapping_id,
          km.kpi_name,
          rkm.weightage
        FROM role_kpi_mapping rkm
        JOIN kpi_master km ON km.id = rkm.kpi_id
        WHERE rkm.role = ? AND rkm.deleted_at IS NULL
        ORDER BY rkm.id
        `,
        [role],
        (err, rows) => {
          if (err) return reject(err);
          resolve(rows);
        },
      );
    });

    if (!kpiList.length) {
      return res.status(404).json({ error: "No KPI found for role" });
    }

    const staffRows = await new Promise((resolve, reject) => {
      pool.query(
        `
        SELECT id AS staffId, name AS staffName
        FROM users
        WHERE role = 'HO_staff' AND hod_id = ? AND period = ?
        `,
        [hod_id, period],
        (err, rows) => {
          if (err) return reject(err);
          resolve(rows);
        },
      );
    });

    if (!staffRows.length) {
      return res.json([]);
    }

    const staffIds = staffRows.map((s) => s.staffId);

    const allUserEntries = await new Promise((resolve) => {
      pool.query(
        `
        SELECT role_kpi_mapping_id, value AS achieved, user_id
        FROM user_kpi_entry
        WHERE period = ?
        AND user_id IN (?)
        AND deleted_at IS NULL
        `,
        [period, staffIds],
        (err, rows) => resolve(rows || []),
      );
    });

    const allInsuranceEntries = await new Promise((resolve) => {
      pool.query(
        `
        SELECT employee_id, value AS achieved
        FROM entries
        WHERE kpi = 'insurance'
        AND employee_id IN (?)
        `,
        [staffIds],
        (err, rows) => resolve(rows || []),
      );
    });

    const userEntryMap = {};

    allUserEntries.forEach((e) => {
      if (!userEntryMap[e.user_id]) {
        userEntryMap[e.user_id] = {};
      }

      userEntryMap[e.user_id][e.role_kpi_mapping_id] = Number(e.achieved || 0);
    });

    const insuranceMap = {};

    allInsuranceEntries.forEach((e) => {
      insuranceMap[e.employee_id] = Number(e.achieved || 0);
    });

    const result = [];

    // CACHE MAPS
    const hoHistoryCache = new Map();
    const attHistoryCache = new Map();
    const transferHistoryCache = new Map();

    // BATCH PROCESSING
    const batchSize = 10;

    for (let i = 0; i < staffRows.length; i += batchSize) {
      const batch = staffRows.slice(i, i + batchSize);

      const batchResults = await Promise.all(
        batch.map(async (staff) => {
          const staffId = staff.staffId;

          const achievedMap = userEntryMap[staffId] || {};
          const insuranceValue = insuranceMap[staffId] || 0;

          const staffObj = {
            staffId,
            staffName: staff.staffName,
          };

          let totalWeightageScore = 0;

          for (const kpi of kpiList) {
            const { role_kpi_mapping_id, kpi_name, weightage } = kpi;

            let achieved = 0;

            if (kpi_name.toLowerCase() === "insurance") {
              achieved = insuranceValue;
            } else {
              achieved =
                achievedMap[role_kpi_mapping_id] !== undefined
                  ? achievedMap[role_kpi_mapping_id]
                  : 0;
            }

            const target =
              kpi_name.toLowerCase() === "insurance" ? 40000 : weightage;

            let score = 0;

            if (achieved > 0) {
              if (kpi_name.toLowerCase() === "insurance") {
                const ratio = achieved / target;

                if (ratio <= 1) score = ratio * 10;
                else if (ratio < 1.25) score = 10;
                else score = 12.5;
              } else {
                const ratio = achieved / target;

                if (ratio <= 1) score = ratio * 10;
                else if (ratio < 1.25) score = 10;
                else score = 12.5;
              }
            }

            let weightageScore = (score * weightage) / 100;

            // no insurance -2 penalty

            totalWeightageScore += weightageScore;

            staffObj[kpi_name] = {
              score: Number(score.toFixed(2)),
              achieved,
              weightage,
              weightageScore: Number(weightageScore.toFixed(2)),
            };
          }

          const finalScores = {
            total: Number(totalWeightageScore.toFixed(2)),
          };

          // HO HISTORY CACHE
          let hoHistory = hoHistoryCache.get(staffId);

          if (!hoHistory) {
            hoHistory = await new Promise((resolve) => {
              getHoStaffTransferHistory(pool, period, staffId, (err, data) => {
                if (err) return resolve([]);

                resolve(data);
              });
            });

            hoHistoryCache.set(staffId, hoHistory);
          }

          const previousHoScores =
            hoHistory?.[0]?.transfers?.map((t) =>
              Number(t.total_weightage_score),
            ) || [];

          // ATT HISTORY CACHE
          let attHistory = attHistoryCache.get(staffId);

          if (!attHistory) {
            attHistory = await new Promise((resolve) => {
              getAttenderTransferHistory(pool, period, staffId, (err, data) => {
                if (err) return resolve([]);

                resolve(data);
              });
            });

            attHistoryCache.set(staffId, attHistory);
          }

          const previousAttenderScores =
            attHistory?.[0]?.transfers?.map((t) =>
              Number(t.total_weightage_score),
            ) || [];

          // TRANSFER CACHE
          let transferHistory = transferHistoryCache.get(staffId);

          if (!transferHistory) {
            transferHistory = await getTransferKpiHistory(
              pool,
              period,
              staffId,
            );

            transferHistoryCache.set(staffId, transferHistory);
          }

          const previousTransferScores =
            transferHistory?.all_scores?.map(Number) || [];

          const allScores = [
            ...previousHoScores,
            ...previousAttenderScores,
            ...previousTransferScores,
            finalScores.total,
          ];

          const finalAvg =
            allScores.length > 0
              ? allScores.reduce((a, b) => a + b, 0) / allScores.length
              : 0;

          staffObj.originalTotal = Number(totalWeightageScore.toFixed(2));

          staffObj.total = Number(finalAvg.toFixed(2));

          return staffObj;
        }),
      );

      result.push(...batchResults);
    }

    res.json(result);
  } catch (error) {
    console.error(error);

    res.status(500).json({
      error: "Failed to load HO staff scores",
    });
  }
});

// Save or update HO staff KPI scores
performanceMasterRouter.post("/save-or-update-ho-staff-kpi", (req, res) => {
  const { user_id, period, master_user_id, scores } = req.body;

  if (!user_id || !master_user_id || !period || !Array.isArray(scores)) {
    return res.status(400).json({
      error:
        "user_id, master_user_id, period and valid scores array are required",
    });
  }

  const filteredScores = scores.filter(
    (s) =>
      s &&
      s.role_kpi_mapping_id &&
      s.value !== undefined &&
      s.kpi_name?.toLowerCase() !== "insurance",
  );

  if (filteredScores.length === 0) {
    return res.json({
      message: "No KPI to save (Insurance excluded)",
    });
  }

  pool.getConnection((err, conn) => {
    if (err) return res.status(500).json(err);

    conn.beginTransaction((err) => {
      if (err) {
        conn.release();
        return res.status(500).json(err);
      }

      let completed = 0;
      let hasError = false;

      const inserted = [];
      const updated = [];

      filteredScores.forEach((s) => {
        const userId = Number(user_id);
        const roleId = Number(s.role_kpi_mapping_id);
        const value = Number(s.value);
        const periodVal = String(period).trim();
        const masterId = Number(master_user_id);

        conn.query(
          `UPDATE user_kpi_entry 
           SET value = ?, master_user_id = ?, updated_at = CURRENT_TIMESTAMP
           WHERE user_id = ? 
           AND role_kpi_mapping_id = ? 
           AND period = ?`,
          [value, masterId, userId, roleId, periodVal],
          (err, updateResult) => {
            if (err) return rollback(err);

            if (updateResult.affectedRows > 0) {
              updated.push(`${s.kpi_name} updated`);
              done();
            } else {
              conn.query(
                `INSERT INTO user_kpi_entry 
                 (user_id, role_kpi_mapping_id, period, value, master_user_id)
                 VALUES (?, ?, ?, ?, ?)`,
                [userId, roleId, periodVal, value, masterId],
                (err2) => {
                  if (err2) return rollback(err2);

                  inserted.push(`${s.kpi_name} inserted`);
                  done();
                },
              );
            }
          },
        );
      });

      function done() {
        completed++;
        if (completed === filteredScores.length && !hasError) {
          conn.commit((err) => {
            if (err) return rollback(err);

            conn.release();
            res.json({
              message: "KPI save/update successful",
              totalProcessed: filteredScores.length,
              inserted,
              updated,
            });
          });
        }
      }

      function rollback(error) {
        if (hasError) return;
        hasError = true;

        conn.rollback(() => {
          conn.release();
          console.error("Transaction Error =>", error);

          res.status(500).json({
            error: "Transaction failed ",
            details: error,
          });
        });
      }
    });
  });
});

//get Dashboard Data
const bmScoreCache = new Map();
performanceMasterRouter.post(
  "/get-Total-Ho_staff-details",
  async (req, res) => {
    const { hod_id, period } = req.body;

    if (!hod_id || !period) {
      return res.status(400).json({
        error: "hod_id and period are required",
      });
    }

    try {
      const dashboardResult = {};

      // PARALLEL LIGHT QUERIES ONLY
      const [hoStaffResult, branches, agmDgmResult] = await Promise.all([
        new Promise((resolve, reject) => {
          pool.query(
            `
              SELECT 
                username,
                name,
                role

              FROM users

              WHERE role='HO_STAFF'
              AND hod_id = ?
              AND period = ?
              `,
            [hod_id, period],

            (err, rows) => {
              if (err) {
                return reject(err);
              }

              resolve(rows);
            },
          );
        }),

        new Promise((resolve, reject) => {
          pool.query(
            `
              SELECT 
                code,
                name

              FROM branches

              WHERE incharge_id = ?
              AND period = ?
              `,
            [hod_id, period],

            (err, rows) => {
              if (err) {
                return reject(err);
              }

              resolve(rows);
            },
          );
        }),

        new Promise((resolve, reject) => {
          pool.query(
            `
              SELECT 
                username,
                name,
                role

              FROM users

              WHERE role IN (
                'AGM',
                'DGM',
                'AGM_IT',
                'AGM_INSURANCE',
                'AGM_AUDIT'
              )

              AND period = ?
              `,
            [period],

            (err, rows) => {
              if (err) {
                return reject(err);
              }

              resolve(rows);
            },
          );
        }),
      ]);

      dashboardResult.totalHOStaff = hoStaffResult;

      dashboardResult.totalHOStaffCount = hoStaffResult.length;

      const allBranchScores = await calculateBMScores(period);

      const branchesWithScore = branches.map((branch) => {
        try {
          const cacheKey = `${period}_${branch.code}`;

          if (bmScoreCache.has(cacheKey)) {
            return {
              ...branch,

              bmTotalScore: bmScoreCache.get(cacheKey),
            };
          }

          const total = allBranchScores?.[branch.code]?.total || 0;

          bmScoreCache.set(cacheKey, total);

          return {
            ...branch,

            bmTotalScore: total,
          };
        } catch {
          return {
            ...branch,

            bmTotalScore: 0,
          };
        }
      });

      dashboardResult.totalBranches = branchesWithScore;

      dashboardResult.totalBranchesCount = branchesWithScore.length;

      dashboardResult.totalAGMDGM = agmDgmResult;

      dashboardResult.totalAGMDGMCount = agmDgmResult.length;

      res.json(dashboardResult);
    } catch (err) {
      console.error(err);

      res.status(500).json({
        error: "Failed to load HO staff dashboard data",
      });
    }
  },
);

//function to calculate hod calculation
const hodScoreCache = new Map();
const bmScoreCache1 = new Map();
const calculateHodAllScores = async (
  pool,
  period,
  hod_id,
  role,
  calculateStaffScores,
  calculateBMScores,
) => {
  try {
    const [hodKpis, staffRows, branchRows] = await Promise.all([
      new Promise((resolve, reject) => {
        pool.query(
          `
          SELECT 
            k.kpi_name,
            r.id AS role_kpi_mapping_id,
            r.weightage

          FROM role_kpi_mapping r

          JOIN kpi_master k
            ON r.kpi_id = k.id

          WHERE r.role = ?
          `,
          [role],

          (err, rows) => {
            if (err) {
              return reject(err);
            }

            if (!rows.length) {
              return reject("No KPIs found for role");
            }

            resolve(rows);
          },
        );
      }),

      new Promise((resolve, reject) => {
        pool.query(
          `
          SELECT id

          FROM users

          WHERE hod_id = ?
          AND period = ?
          `,
          [hod_id, period],

          (err, rows) => {
            if (err) {
              return reject(err);
            }

            resolve(rows);
          },
        );
      }),

      new Promise((resolve, reject) => {
        pool.query(
          `
          SELECT code

          FROM branches

          WHERE incharge_id = ?
          AND period = ?
          `,
          [hod_id, period],

          (err, rows) => {
            if (err) {
              return reject(err);
            }

            resolve(rows);
          },
        );
      }),
    ]);

    const kpiMap = {};

    for (const k of hodKpis) {
      kpiMap[k.kpi_name] = {
        id: k.role_kpi_mapping_id,

        weightage: k.weightage,
      };
    }

    const staffIds = staffRows.map((r) => r.id);

    const branchCodes = branchRows.map((r) => r.code);

    const limit = pLimit(10);

    const staffPromises = staffIds.map((id) =>
      limit(async () => {
        try {
          const cacheKey = `${period}_${id}`;

          if (hodScoreCache.has(cacheKey)) {
            return hodScoreCache.get(cacheKey);
          }

          const score = await calculateStaffScores(period, id, "HO_STAFF");

          hodScoreCache.set(cacheKey, score);

          return score;
        } catch {
          return {
            total: 0,
          };
        }
      }),
    );

    const staffScores = await Promise.all(staffPromises);

    let staffTotal = 0;

    for (const v of staffScores) {
      staffTotal += v.total || 0;
    }

    const staffAvgScore = Number(
      (staffTotal / (staffScores.length || 1)).toFixed(2),
    );

    const allBranchScores = await calculateBMScores(period);

    const bmPromises = branchCodes.map(async (code) => {
      try {
        const cacheKey = `${period}_${code}`;

        if (bmScoreCache1.has(cacheKey)) {
          return bmScoreCache1.get(cacheKey);
        }

        const total = Number((allBranchScores?.[code]?.total || 0).toFixed(2));

        bmScoreCache1.set(cacheKey, total);

        return total;
      } catch {
        return 0;
      }
    });

    const bmTotals = await Promise.all(bmPromises);

    let bmTotal = 0;

    for (const v of bmTotals) {
      bmTotal += v;
    }

    const branchAvgScore = Number(
      (bmTotal / (bmTotals.length || 1)).toFixed(2),
    );

    const [userKpiValues, insuranceValue] = await Promise.all([
      new Promise((resolve, reject) => {
        pool.query(
          `
          SELECT 
            role_kpi_mapping_id,
            SUM(value) AS total

          FROM user_kpi_entry

          WHERE user_id = ?
          AND period = ?

          GROUP BY role_kpi_mapping_id
          `,
          [hod_id, period],

          (err, rows) => {
            if (err) {
              return reject(err);
            }

            const map = {};

            for (const r of rows) {
              map[r.role_kpi_mapping_id] = Number(r.total || 0);
            }

            resolve(map);
          },
        );
      }),

      new Promise((resolve, reject) => {
        if (!Object.keys(kpiMap).some((k) => k.toLowerCase() === "insurance")) {
          return resolve(0);
        }

        pool.query(
          `
          SELECT 
            SUM(value) AS total

          FROM entries

          WHERE kpi='insurance'
          AND employee_id=?
          AND period=?
          `,
          [hod_id, period],

          (err, rows) => {
            if (err) {
              return reject(err);
            }

            resolve(Number(rows[0]?.total || 0));
          },
        );
      }),
    ]);

    const getKpiVal = (name) => userKpiValues[kpiMap[name]?.id] || 0;

    const Cleanliness = getKpiVal("HO Building Cleanliness");

    const Management = getKpiVal("Management  Discretion");

    const InternalAudit = getKpiVal("Internal Audit performance");

    const IT = getKpiVal("IT");

    const InsuranceBusinessDevelopment = getKpiVal(
      "Insurance Business Development",
    );

    let finalKpis = {};

    let Total = 0;

    for (const kpi of hodKpis) {
      const name = kpi.kpi_name;

      const weightage = kpi.weightage;

      const lowerName = name.toLowerCase();

      let avg = 0;
      let result = 0;
      let weightageScore = 0;
      let rangeCovert = 0;

      if (lowerName.includes("section")) {
        avg = staffAvgScore;
      } else if (lowerName.includes("branch") || lowerName.includes("visits")) {
        avg = branchAvgScore;
      } else if (lowerName.includes("clean")) {
        avg = Cleanliness;
      } else if (lowerName.includes("management")) {
        avg = Management;
      } else if (lowerName.includes("audit")) {
        avg = InternalAudit;
      } else if (lowerName.includes("it")) {
        avg = IT;
      } else if (lowerName.includes("insurance business development")) {
        avg = InsuranceBusinessDevelopment;
      }

      rangeCovert = (avg / 10) * weightage;

      if (lowerName === "insurance") {
        const target = 40000;

        avg = insuranceValue;

        if (avg <= target) {
          result = (avg / target) * 10;
        } else if (avg / target < 1.25) {
          result = 10;
        }

        weightageScore = (result / 100) * weightage;
      } else if (
        lowerName.includes("section") ||
        lowerName.includes("branch") ||
        lowerName.includes("visits")
      ) {
        if (rangeCovert === 0) {
          result = 0;
        } else if (rangeCovert <= weightage) {
          result = (rangeCovert / weightage) * 10;
        } else if (rangeCovert / weightage < 1.25) {
          result = 12.5;
        } else {
          result = 0;
        }

        weightageScore = (result / 100) * weightage;
      } else {
        if (avg === 0) {
          result = 0;
        } else if (avg <= weightage) {
          result = (avg / weightage) * 10;
        } else if (avg / weightage < 1.25) {
          result = 12.5;
        } else {
          result = 0;
        }

        weightageScore = (result / 100) * weightage;
      }

      Total += weightageScore;

      finalKpis[name] = {
        score: Number(result.toFixed(2)),

        achieved:
          lowerName.includes("section") ||
            lowerName.includes("branch") ||
            lowerName.includes("visits")
            ? Number(rangeCovert.toFixed(2))
            : avg || 0,

        weightage,

        weightageScore: Number(weightageScore.toFixed(2)),
      };
    }

    return {
      hod_id,

      period,

      kpis: finalKpis,

      total: Number(Total.toFixed(2)),
    };
  } catch (err) {
    throw err;
  }
};

//calculate AGM-DGM Score
const agmScoreCache = new Map();
performanceMasterRouter.get("/AGM-DGM-Scores", async (req, res) => {
  const { period } = req.query;

  if (!period) {
    return res.status(400).json({
      error: "period required",
    });
  }

  try {
    // LOAD AGM LIST
    const agmList = await new Promise((resolve, reject) => {
      pool.query(
        `
              SELECT 
                id AS hod_id,
                role,
                name
              FROM users
              WHERE role IN (
                'AGM',
                'DGM',
                'AGM_AUDIT',
                'AGM_INSURANCE',
                'AGM_IT'
              )
              AND period = ?
              `,
        [period],
        (err, rows) => {
          if (err) {
            return reject(err);
          }

          resolve(rows);
        },
      );
    });

    // 1. Pre-calculate and cache BM scores
    await calculateBMScores(period);

    // 2. Pre-calculate and cache staff scores
    if (agmList.length > 0) {
      const agmIds = agmList.map((u) => u.hod_id);
      const staffRows = await new Promise((resolve, reject) => {
        pool.query(
          `
          SELECT id FROM users
          WHERE hod_id IN (?)
          AND period = ?
          `,
          [agmIds, period],
          (err, rows) => (err ? reject(err) : resolve(rows)),
        );
      });
      const staffIds = staffRows.map((r) => r.id);

      if (staffIds.length > 0) {
        const staffScoresBatchMap = await calculateStaffScoresBatch(
          period,
          staffIds,
          "HO_STAFF",
        );
        for (const [id, score] of Object.entries(staffScoresBatchMap)) {
          hodScoreCache.set(`${period}_${id}`, score);
        }
      }
    }

    // 3. Process all HOD users in parallel
    const results = await Promise.all(
      agmList.map(async (agm) => {
        try {
          const cacheKey = `${period}_${agm.hod_id}_${agm.role}`;

          // CACHE HIT
          if (agmScoreCache.has(cacheKey)) {
            return {
              hod_id: agm.hod_id,
              name: agm.name,
              role: agm.role,
              ...agmScoreCache.get(cacheKey),
            };
          }

          // HEAVY FUNCTION
          const scoreData = await calculateHodAllScores(
            pool,
            period,
            agm.hod_id,
            agm.role,
            calculateStaffScores,
            calculateBMScores,
          );

          // SAVE CACHE
          agmScoreCache.set(cacheKey, scoreData);

          return {
            hod_id: agm.hod_id,
            name: agm.name,
            role: agm.role,
            ...scoreData,
          };
        } catch (err) {
          console.error(err);

          return {
            hod_id: agm.hod_id,
            name: agm.name,
            role: agm.role,
            kpis: {},
            total: 0,
          };
        }
      }),
    );

    res.json(results);
  } catch (err) {
    console.error(err);

    res.status(500).json({
      error: "Failed to calculate AGM/DGM scores",
    });
  }
});
//Deputation Staff Report API
performanceMasterRouter.post("/deputation-report", (req, res) => {
  const { period, department } = req.body;

  let sql = `
    SELECT
      emp_id,
      name,
      place,
      design,
      branch,
      work_at,
      weightage_score,
      department
    FROM deputation_staff
    WHERE 1 = 1
  `;

  const params = [];

  if (department && department !== "All") {
    sql += " AND department = ?";
    params.push(department);
  }

  if (period) {
    sql += " AND period = ?";
    params.push(period);
  }

  sql += " ORDER BY department, name";

  pool.query(sql, params, (err, rows) => {
    if (err) return res.status(500).json(err);
    res.json(rows);
  });
});

const branchScoreCache1 = new Map();

performanceMasterRouter.post("/getAllBranchesScore", async (req, res) => {
  const { period } = req.body;

  if (!period) {
    return res.status(400).json({
      error: "period is required",
    });
  }

  try {
    const branchReportData = {};

    const branches = await new Promise((resolve, reject) => {
      pool.query(
        `
              SELECT 
                code,
                name

              FROM branches

              WHERE period = ?
              `,
        [period],

        (err, rows) => {
          if (err) {
            return reject(err);
          }

          resolve(rows || []);
        },
      );
    });

    const allBranchScores = await calculateBMScores(period);

    const bmUsers = await new Promise((resolve, reject) => {
      pool.query(
        `
              SELECT 
                PF_NO,
                name,
                branch_id

              FROM users

              WHERE role='BM'
              AND period = ?
              `,
        [period],

        (err, rows) => {
          if (err) {
            return reject(err);
          }

          resolve(rows || []);
        },
      );
    });

    const bmMap = {};

    bmUsers.forEach((bm) => {
      bmMap[bm.branch_id] = bm;
    });

    const batchSize = 5;

    const branchesWithScore = [];

    for (let i = 0; i < branches.length; i += batchSize) {
      const batch = branches.slice(i, i + batchSize);

      const batchResults = await Promise.all(
        batch.map(async (branch) => {
          try {
            const cacheKey = `${period}_${branch.code}`;

            if (branchScoreCache1.has(cacheKey)) {
              return {
                ...branch,

                ...branchScoreCache1.get(cacheKey),
              };
            }

            const bm = bmMap[branch.code];

            const total = allBranchScores?.[branch.code]?.total || 0;

            const result = {
              bmId: bm?.PF_NO ?? null,

              bmName: bm?.name ?? null,

              bmTotalScore: total,
            };

            branchScoreCache1.set(cacheKey, result);

            return {
              ...branch,

              ...result,
            };
          } catch (err) {
            console.error(`BM score failed for branch ${branch.code}`, err);

            return {
              ...branch,

              bmId: null,

              bmName: null,

              bmTotalScore: 0,
            };
          }
        }),
      );

      branchesWithScore.push(...batchResults);
    }

    branchReportData.totalBranches = branchesWithScore;

    branchReportData.totalBranchesCount = branchesWithScore.length;

    res.json(branchReportData);
  } catch (err) {
    console.error(err);

    res.status(500).json({
      error: "Failed to load branch report data",
    });
  }
});

//single clerk kpi score
async function calculateStaffScoresCb(period) {
  try {
    const query = `
     SELECT 
        emp.id AS employee_id,
        emp.branch_id,
        emp.role,

        k.kpi,

        MAX(
            CASE 

                WHEN k.kpi = 'recovery'
                    AND (
                        emp.transfer_date 
                            BETWEEN fy.fy_start 
                            AND fy.fy_end

                        OR

                        emp.user_add_date 
                            BETWEEN fy.fy_start 
                            AND fy.fy_end
                    )

                THEN COALESCE(a.amount, 0)

                WHEN k.kpi = 'recovery'

                THEN COALESCE(t.amount, 0)

                ELSE COALESCE(a.amount, 0)

            END
        ) AS target,

        MAX(
            COALESCE(w.weightage, 0)
        ) AS weightage,

        MAX(
            COALESCE(e.total_achieved, 0) + COALESCE(prev.amount, 0)
        ) AS achieved,
        MAX(
            COALESCE(prev.amount, 0)
        ) AS baseline

    FROM users emp

    CROSS JOIN
    (
        SELECT 'deposit' AS kpi
        UNION ALL SELECT 'loan_gen'
        UNION ALL SELECT 'loan_amulya'
        UNION ALL SELECT 'audit'
        UNION ALL SELECT 'recovery'
        UNION ALL SELECT 'insurance'
    ) k

    CROSS JOIN
    (
        SELECT 
            STR_TO_DATE(
                CONCAT(
                    SUBSTRING(?,1,4),
                    '-04-01'
                ),
                '%Y-%m-%d'
            ) AS fy_start,

            STR_TO_DATE(
                CONCAT(
                    '20',
                    SUBSTRING(?,6,2),
                    '-03-31'
                ),
                '%Y-%m-%d'
            ) AS fy_end
    ) fy

    LEFT JOIN allocations a
        ON a.kpi = k.kpi
        AND a.period = ?
        AND a.user_id = emp.id
        AND a.branch_id = emp.branch_id

    LEFT JOIN targets t
        ON t.kpi = k.kpi
        AND t.period = ?
        AND t.branch_id = emp.branch_id

    LEFT JOIN weightage w
        ON w.kpi = k.kpi

    LEFT JOIN
    (
        SELECT
            z.employee_id,
            z.branch_id,
            z.kpi,

            SUM(z.value)
                AS total_achieved

        FROM
        (

            -- AUDIT / RECOVERY
            SELECT
                emp2.id AS employee_id,
                emp2.branch_id,
                e.kpi,
                e.value

            FROM users emp2

            CROSS JOIN
            (
                SELECT 
                    STR_TO_DATE(
                        CONCAT(
                            SUBSTRING(?,1,4),
                            '-04-01'
                        ),
                        '%Y-%m-%d'
                    ) AS fy_start,

                    STR_TO_DATE(
                        CONCAT(
                            '20',
                            SUBSTRING(?,6,2),
                            '-03-31'
                        ),
                        '%Y-%m-%d'
                    ) AS fy_end
            ) fy

            LEFT JOIN
            (
                SELECT
                    branch_id,
                    MIN(id) AS id,
                    period

                FROM users

                WHERE role = 'BM'

                GROUP BY
                    branch_id,
                    period

            ) bmMap
                ON bmMap.branch_id =
                    emp2.branch_id
                AND bmMap.period =
                    emp2.period

            LEFT JOIN users bm
                ON bm.id = bmMap.id

            JOIN entries e
                ON e.period = ?
                AND e.status = 'Verified'
                AND e.branch_id =
                    emp2.branch_id

                AND e.kpi IN (
                    'audit',
                    'recovery'
                )

                AND
                (
                    (
                        (
                            emp2.user_add_date 
                                BETWEEN fy.fy_start 
                                AND fy.fy_end

                            OR

                            emp2.transfer_date 
                                BETWEEN fy.fy_start 
                                AND fy.fy_end
                        )

                        AND e.employee_id =
                            emp2.id
                    )

                    OR

                    (
                        (
                            emp2.user_add_date IS NULL

                            OR

                            emp2.user_add_date <
                                fy.fy_start
                        )

                        AND
                        (
                            emp2.transfer_date IS NULL

                            OR

                            emp2.transfer_date <
                                fy.fy_start
                        )

                        AND e.employee_id =
                            bm.id
                    )
                )

            WHERE
                emp2.period = ?
                AND emp2.role = 'Clerk'

            UNION ALL

            -- OTHER KPI
            SELECT
                e.employee_id,
                e.branch_id,
                e.kpi,
                e.value

            FROM entries e

            JOIN users emp3
                ON emp3.id = e.employee_id
                AND emp3.role = 'Clerk'
                AND emp3.period = ?
                AND emp3.branch_id =
                    e.branch_id

            WHERE
                e.period = ?
                AND e.status = 'Verified'
                AND e.kpi IN (
                    'deposit',
                    'loan_gen',
                    'loan_amulya',
                    'insurance'
                )

        ) z

        GROUP BY
            z.employee_id,
            z.branch_id,
            z.kpi

    ) e
        ON e.employee_id = emp.id
        AND e.branch_id = emp.branch_id
        AND e.kpi = k.kpi

    LEFT JOIN (
        SELECT employee_id, branch_id, kpi, SUM(amount) AS amount
        FROM previous_period_data_staffwise
        WHERE period = ? AND deleted_at IS NULL
        GROUP BY employee_id, branch_id, kpi
    ) prev
        ON prev.employee_id COLLATE utf8mb4_unicode_ci = emp.id COLLATE utf8mb4_unicode_ci
        AND prev.branch_id COLLATE utf8mb4_unicode_ci = emp.branch_id COLLATE utf8mb4_unicode_ci
        AND prev.kpi COLLATE utf8mb4_unicode_ci = k.kpi COLLATE utf8mb4_unicode_ci

    WHERE
        emp.period = ?
        AND emp.role = 'Clerk'

    GROUP BY
        emp.id,
        emp.branch_id,
        emp.role,
        k.kpi

    ORDER BY
        emp.branch_id,
        emp.id,
        k.kpi
    `;

    const results = await new Promise((resolve, reject) => {
      pool.query(
        query,
        [
          period,
          period,
          period,
          period,
          period,
          period,
          period,
          period,
          period,
          period,
          period,
          period,
        ],
        (err, rows) => {
          if (err) {
            return reject(err);
          }

          resolve(rows || []);
        },
      );
    });

    const grouped = {};

    for (const row of results) {
      const employeeId = row.employee_id;

      if (!grouped[employeeId]) {
        grouped[employeeId] = [];
      }

      grouped[employeeId].push(row);
    }

    const finalResponse = {};

    const employeeIds = Object.keys(grouped);

    const [hoTransferData, attTransferData, transferKpiData] =
      await Promise.all([
        Promise.all(
          employeeIds.map(
            (id) =>
              new Promise((resolve, reject) => {
                getHoStaffTransferHistory(
                  pool,
                  period,
                  id,

                  (err, data) => {
                    if (err) {
                      return reject(err);
                    }

                    resolve({
                      id,
                      data,
                    });
                  },
                );
              }),
          ),
        ),

        Promise.all(
          employeeIds.map(
            (id) =>
              new Promise((resolve, reject) => {
                getAttenderTransferHistory(
                  pool,
                  period,
                  id,

                  (err, data) => {
                    if (err) {
                      return reject(err);
                    }

                    resolve({
                      id,
                      data,
                    });
                  },
                );
              }),
          ),
        ),

        Promise.all(
          employeeIds.map(async (id) => {
            const data = await getTransferKpiHistory(pool, period, id);

            return {
              id,
              data,
            };
          }),
        ),
      ]);

    const hoMap = {};
    const attMap = {};
    const transferMap = {};

    hoTransferData.forEach((x) => {
      hoMap[x.id] = x.data;
    });

    attTransferData.forEach((x) => {
      attMap[x.id] = x.data;
    });

    transferKpiData.forEach((x) => {
      transferMap[x.id] = x.data;
    });

    for (const employeeId in grouped) {
      const employeeRows = grouped[employeeId];

      const scores = {};

      let totalWeightageScore = 0;

      let auditRatio = 0;
      let recoveryRatio = 0;

      for (const row of employeeRows) {
        if (row.kpi === "audit") {
          auditRatio = Number(row.achieved || 0) / Number(row.target || 1);
        }

        if (row.kpi === "recovery") {
          recoveryRatio = Number(row.achieved || 0) / Number(row.target || 1);
        }
      }

      for (const row of employeeRows) {
        const previousBalance = Number(row.baseline) || 0;
        const newTarget = Number(row.target) || 0;
        const totalTarget = previousBalance + newTarget;
        const currentAchieved = Number(row.achieved) || 0;

        const isBaselineOnly =
          previousBalance > 0 && currentAchieved <= previousBalance;
        const score = isBaselineOnly
          ? 0
          : calculateScore(
            row.kpi,
            previousBalance > 0 ? currentAchieved - previousBalance : currentAchieved,
            newTarget,
            auditRatio,
            recoveryRatio,
          );

        const weightageScore = isBaselineOnly
          ? 0
          : (score * row.weightage) / 100;

        scores[row.kpi] = {
          score,
          previousBalance,
          newTarget,
          totalTarget,
          target: totalTarget, // for backward compatibility with UI
          achieved: isBaselineOnly ? 0 : currentAchieved,
          weightage: row.weightage || 0,
          weightageScore,
        };

        totalWeightageScore += weightageScore;
      }

      const hoHistory = hoMap[employeeId];
      const attHistory = attMap[employeeId];
      const transferHistory = transferMap[employeeId];

      const previousHoTransfers = hoHistory?.[0]?.transfers || [];
      const previousAttTransfers = attHistory?.[0]?.transfers || [];
      const previousClerkTransfers = transferHistory?.transfers || [];

      const allTransfers = [
        ...previousHoTransfers,
        ...previousAttTransfers,
        ...previousClerkTransfers,
      ];

      let isTransferClerkOrBm = allTransfers.length > 0;
      let finalAvg = 0;

      if (isTransferClerkOrBm) {
        let sumOfPrevious = 0;

        allTransfers.forEach((t) => {
          const rawScore = Number(t.total_weightage_score || 0);
          const months = Number(t.months || 0);
          const proportionateScore = months > 0 ? (rawScore / 12) * months : rawScore;
          sumOfPrevious += proportionateScore;
        });

        const currentScoreExcludingInsurance =
          Number(scores.deposit?.weightageScore || 0) +
          Number(scores.loan_gen?.weightageScore || 0) +
          Number(scores.loan_amulya?.weightageScore || 0) +
          Number(scores.recovery?.weightageScore || 0) +
          Number(scores.audit?.weightageScore || 0);

        const averageExcludingInsurance = sumOfPrevious + currentScoreExcludingInsurance;
        const insuranceScore = Number(scores.insurance?.weightageScore || 0);
        finalAvg = averageExcludingInsurance + insuranceScore;

        scores.originalTotal = Number((currentScoreExcludingInsurance + insuranceScore).toFixed(2));
      } else {
        const previousHoScores =
          hoHistory?.[0]?.transfers?.map((t) => t.total_weightage_score) || [];

        const previousAttenderScores =
          attHistory?.[0]?.transfers?.map((t) => t.total_weightage_score) || [];

        const previousTransferScores = transferHistory?.all_scores || [];

        const allScores = [
          ...previousHoScores,
          ...previousAttenderScores,
          ...previousTransferScores,
          totalWeightageScore,
        ];

        finalAvg =
          allScores.length > 0
            ? allScores.reduce((a, b) => a + b, 0) / allScores.length
            : 0;

        scores.originalTotal = Number(totalWeightageScore.toFixed(2));
      }

      if (Number(employeeId) === 2947) {
        console.log("Final Avg =>", finalAvg);
      }

      scores.total = Number(finalAvg.toFixed(2));

      finalResponse[employeeId] = scores;
    }

    return finalResponse;
  } catch (err) {
    throw err;
  }
}
// helper function for the calculateScore accroding to the kpis
function calculateScore(
  kpi,
  achieved,
  target,
  auditRatio = 0,
  recoveryRatio = 0,
) {
  let outOf10 = 0;

  achieved = Number(achieved) || 0;
  target = Number(target) || 0;

  if (!target) return 0;

  const ratio = achieved / target;

  switch (kpi) {
    case "deposit":
    case "loan_gen":
    case "loan_amulya":
      if (ratio <= 1) {
        outOf10 = ratio * 10;
      } else if (ratio < 1.25) {
        outOf10 = 10;
      } else if (auditRatio >= 0.75 && recoveryRatio >= 0.75) {
        outOf10 = 12.5;
      } else {
        outOf10 = 10;
      }

      break;

    case "insurance":
      if (ratio === 0) {
        outOf10 = 0;
      } else if (ratio <= 1) {
        outOf10 = ratio * 10;
      } else if (ratio < 1.25) {
        outOf10 = 10;
      } else {
        outOf10 = 12.5;
      }

      break;

    case "audit":
    case "recovery":
      if (ratio <= 1) {
        outOf10 = ratio * 10;
      } else {
        outOf10 = 12.5;
      }

      break;

    default:
      outOf10 = 0;
  }

  return Math.max(
    0,
    Math.min(12.5, isNaN(outOf10) ? 0 : Number(outOf10.toFixed(2))),
  );
}

//single hostaff
async function calculateSpecificAllStaffScoresCb(period, role) {
  try {
    const [kpiWeightage, userEntries, insuranceRows, users] = await Promise.all(
      [
        new Promise((resolve, reject) => {
          pool.query(
            `
            SELECT 
              rkm.id AS role_kpi_mapping_id,
              km.kpi_name,
              rkm.weightage

            FROM role_kpi_mapping rkm

            JOIN kpi_master km
              ON km.id = rkm.kpi_id

            WHERE rkm.role = ?
            AND rkm.deleted_at IS NULL
            `,
            [role],

            (err, rows) => {
              if (err) {
                return reject(err);
              }

              resolve(rows || []);
            },
          );
        }),

        new Promise((resolve, reject) => {
          pool.query(
            `
            SELECT 
              user_id,
              role_kpi_mapping_id,
              value AS achieved

            FROM user_kpi_entry

            WHERE period = ?
            AND deleted_at IS NULL
            `,
            [period],

            (err, rows) => {
              if (err) {
                return reject(err);
              }

              resolve(rows || []);
            },
          );
        }),

        new Promise((resolve, reject) => {
          pool.query(
            `
            SELECT 
              employee_id,
              value AS achieved

            FROM entries

            WHERE kpi='insurance'
            `,
            [],

            (err, rows) => {
              if (err) {
                return reject(err);
              }

              resolve(rows || []);
            },
          );
        }),

        new Promise((resolve, reject) => {
          pool.query(
            `
            SELECT 
              id,
              username,
              name,
              role

            FROM users

            WHERE role = ?
            AND period = ?
            `,
            [role, period],

            (err, rows) => {
              if (err) {
                return reject(err);
              }

              resolve(rows || []);
            },
          );
        }),
      ],
    );

    if (!kpiWeightage.length) {
      throw new Error("No KPI found for this role");
    }

    const entryMap = {};

    userEntries.forEach((e) => {
      if (!entryMap[e.user_id]) {
        entryMap[e.user_id] = {};
      }

      entryMap[e.user_id][e.role_kpi_mapping_id] = Number(e.achieved || 0);
    });

    const insuranceMap = {};

    insuranceRows.forEach((r) => {
      insuranceMap[r.employee_id] = Number(r.achieved || 0);
    });

    const userIds = users.map((u) => u.id);

    const [hoTransferData, attTransferData, transferKpiData] =
      await Promise.all([
        Promise.all(
          userIds.map(
            (id) =>
              new Promise((resolve, reject) => {
                getHoStaffTransferHistory(
                  pool,
                  period,
                  id,

                  (err, data) => {
                    if (err) {
                      return reject(err);
                    }

                    resolve({
                      id,
                      data,
                    });
                  },
                );
              }),
          ),
        ),

        Promise.all(
          userIds.map(
            (id) =>
              new Promise((resolve, reject) => {
                getAttenderTransferHistory(
                  pool,
                  period,
                  id,

                  (err, data) => {
                    if (err) {
                      return reject(err);
                    }

                    resolve({
                      id,
                      data,
                    });
                  },
                );
              }),
          ),
        ),

        Promise.all(
          userIds.map(async (id) => {
            const data = await getTransferKpiHistory(pool, period, id);

            return {
              id,
              data,
            };
          }),
        ),
      ]);

    const hoMap = {};
    const attMap = {};
    const transferMap = {};

    hoTransferData.forEach((x) => {
      hoMap[x.id] = x.data;
    });

    attTransferData.forEach((x) => {
      attMap[x.id] = x.data;
    });

    transferKpiData.forEach((x) => {
      transferMap[x.id] = x.data;
    });

    const finalResponse = {};

    for (const user of users) {
      const ho_staff_id = user.id;

      const achievedMap = entryMap[ho_staff_id] || {};

      let totalWeightageScore = 0;

      const scores = {};

      kpiWeightage.forEach((row) => {
        const { role_kpi_mapping_id, kpi_name, weightage } = row;

        let achieved = 0;

        if (kpi_name.toLowerCase() === "insurance") {
          achieved = insuranceMap[ho_staff_id] || 0;
        } else {
          achieved = parseFloat(achievedMap[role_kpi_mapping_id]) || 0;
        }

        const target =
          kpi_name.toLowerCase() === "insurance" ? 40000 : weightage;

        let score = 0;

        if (achieved > 0) {
          const ratio = achieved / target;

          if (ratio <= 1) {
            score = ratio * 10;
          } else if (ratio < 1.25) {
            score = 10;
          } else {
            score = 12.5;
          }
        }

        let weightageScore = (score * weightage) / 100;

        totalWeightageScore += weightageScore;

        scores[kpi_name] = {
          score: Number(score.toFixed(2)),

          achieved,

          weightage,

          weightageScore: Number(weightageScore.toFixed(2)),
        };
      });

      const hoHistory = hoMap[ho_staff_id];

      const attHistory = attMap[ho_staff_id];

      const transferHistory = transferMap[ho_staff_id];

      const previousHoScores =
        hoHistory?.[0]?.transfers?.map((t) => t.total_weightage_score) || [];

      const previousAttenderScores =
        attHistory?.[0]?.transfers?.map((t) => t.total_weightage_score) || [];

      const previousTransferScores = transferHistory?.all_scores || [];

      const allScores = [
        ...previousHoScores,

        ...previousAttenderScores,

        ...previousTransferScores,

        totalWeightageScore,
      ];

      const finalAvg =
        allScores.length > 0
          ? allScores.reduce((a, b) => a + b, 0) / allScores.length
          : 0;

      scores.total = Number(finalAvg.toFixed(2));

      finalResponse[ho_staff_id] = scores;
    }

    return finalResponse;
  } catch (err) {
    throw err;
  }
}
//Transfer BM logic for the Report
function getTransferBmScores(pool, period, branchId, callback) {
  function getFY(period) {
    const [s, e] = period.split("-");
    const sy = parseInt(s);
    const ey = sy - (sy % 100) + parseInt(e);
    return {
      start: new Date(Date.UTC(sy, 3, 1)),
      end: new Date(Date.UTC(ey, 2, 31)),
    };
  }

  function monthDiffStart(d1, d2) {
    const y1 = d1.getUTCFullYear();
    const m1 = d1.getUTCMonth();
    const y2 = d2.getUTCFullYear();
    const m2 = d2.getUTCMonth();
    return Math.max(
      1,
      Math.min(12, (y2 - y1) * 12 + (m2 - m1) + 1)
    );
  }

  const fy = getFY(period);

  pool.query(
    `SELECT id FROM users 
     WHERE branch_id=? AND role='BM' AND period = ?
     ORDER BY transfer_date DESC`,
    [branchId, period],
    (err, BMRows) => {
      if (err) return callback(err);

      const BMID = BMRows?.[0]?.id || BMRows?.[1]?.id || 0;

      if (!BMID) return callback(null, []);

      pool.query(
        `SELECT * FROM bm_transfer_target 
         WHERE staff_id=? AND period=? 
         ORDER BY id DESC LIMIT 1`,
        [BMID, period],
        (err, bmRows) => {
          if (err) return callback(err);

          if (!bmRows.length) return callback(null, []);

          const bm = bmRows[0];

          const transferDate = new Date(bm.transfer_date);
          const totalMonths = monthDiffStart(transferDate, fy.end);

          const bmTargets = {
            deposit: bm.deposit_target || 0,
            loan_gen: bm.loan_gen_target || 0,
            loan_amulya: bm.loan_amulya_target || 0,
            audit: bm.audit_target || 0,
            recovery: bm.recovery_target || 0,
            insurance: bm.insurance_target || 0,
          };

          const monthStart = new Date(
            transferDate.getFullYear(),
            transferDate.getMonth(),
            1,
          );

          pool.query(
            `SELECT kpi, SUM(value) AS achieved
             FROM entries
             WHERE branch_id=? 
             AND period=? 
             AND status='Verified'
             AND date >= ? AND date <= ?
             GROUP BY kpi`,
            [branchId, period, monthStart, fy.end],
            (err, entryRows) => {
              if (err) return callback(err);

              const achievedMap = {};
              entryRows.forEach((r) => (achievedMap[r.kpi] = r.achieved || 0));

              achievedMap["audit"] =
                (achievedMap["audit"] || 0) + (bm.audit_achieved || 0);
              achievedMap["recovery"] =
                (achievedMap["recovery"] || 0) + (bm.recovery_achieved || 0);

              pool.query(
                `SELECT kpi, amount FROM previous_period_data WHERE period = ? AND branch_id = ?`,
                [period, branchId],
                (errPrev, prevRows) => {
                  if (errPrev) return callback(errPrev);

                  const baselineMap = {};
                  prevRows.forEach((r) => (baselineMap[r.kpi] = r.amount || 0));

                  // Add previous period data to achieved for deposit, loan_gen, loan_amulya
                  ["deposit", "loan_gen", "loan_amulya"].forEach((kpi) => {
                    achievedMap[kpi] =
                      (achievedMap[kpi] || 0) + (baselineMap[kpi] || 0);
                  });

                  pool.query(
                    `SELECT SUM(value) AS achieved
                     FROM entries
                     WHERE period=? AND employee_id=? 
                     AND kpi='insurance'
                     AND status='Verified'`,
                    [period, BMID],
                    (err, insRows) => {
                      if (err) return callback(err);

                      achievedMap["insurance"] = insRows?.[0]?.achieved || 0;

                      pool.query(`SELECT * FROM weightage`, (err, wRows) => {
                        if (err) return callback(err);

                        const weightageMap = {};
                        wRows.forEach(
                          (w) => (weightageMap[w.kpi] = w.weightage),
                        );

                        const bmKpis = [
                          "deposit",
                          "loan_gen",
                          "loan_amulya",
                          "recovery",
                          "audit",
                          "insurance",
                        ];

                        function calculateScores(cap) {
                          const scores = {};
                          let total = 0;

                          bmKpis.forEach((kpi) => {
                            const target = bmTargets[kpi] || 0;
                            const achieved = achievedMap[kpi] || 0;
                            const weight = weightageMap[kpi] || 0;
                            const baseline = baselineMap[kpi] || 0;

                            const isBaselineOnly =
                              ["deposit", "loan_gen", "loan_amulya"].includes(
                                kpi,
                              ) &&
                              baseline > 0 &&
                              Number(achieved) <= Number(baseline);

                            let outOf10 = 0;

                            if (target > 0) {
                              if (!isBaselineOnly) {
                                const ratio = achieved / target;
                                const auditRatio = kpi === "audit" ? ratio : 0;
                                const recoveryRatio =
                                  kpi === "recovery" ? ratio : 0;

                                switch (kpi) {
                                  case "deposit":
                                  case "loan_gen":
                                  case "loan_amulya":
                                    if (ratio <= 1) outOf10 = ratio * 10;
                                    else if (ratio < 1.25) outOf10 = 10;
                                    else if (
                                      auditRatio >= 0.75 &&
                                      recoveryRatio >= 0.75
                                    )
                                      outOf10 = 12.5;
                                    else outOf10 = 10;
                                    break;

                                  case "recovery":
                                  case "audit":
                                    outOf10 = ratio <= 1 ? ratio * 10 : 12.5;
                                    break;

                                  case "insurance":
                                    if (ratio === 0) outOf10 = 0;
                                    else if (ratio <= 1) outOf10 = ratio * 10;
                                    else if (ratio < 1.25) outOf10 = 10;
                                    else outOf10 = 12.5;
                                    break;
                                }
                              }
                            }

                            outOf10 = Math.max(0, Math.min(cap, outOf10));

                            let weightScore = isBaselineOnly
                              ? 0
                              : (outOf10 * weight) / 100;

                            scores[kpi] = {
                              score: outOf10,
                              target,
                              achieved,
                              weightage: weight,
                              weightageScore: weightScore,
                            };

                            total += weightScore;
                          });

                          scores["total"] = total;
                          return scores;
                        }

                        const prelim = calculateScores(12.5);

                        const cap =
                          prelim.total > 10 &&
                            prelim.insurance.score < 7.5 &&
                            prelim.recovery.score < 7.5
                            ? 10
                            : 12.5;

                        const finalScores = calculateScores(cap);
                        const totalWeightageScore = finalScores.total;

                        getHoStaffTransferHistory(
                          pool,
                          period,
                          BMID,
                          (errHo, hoHistory) => {
                            if (errHo) return callback(errHo);

                            const previousHoScores =
                              hoHistory?.[0]?.transfers?.map(
                                (t) => t.total_weightage_score,
                              ) || [];

                            getAttenderTransferHistory(
                              pool,
                              period,
                              BMID,
                              (errAtt, attHistory) => {
                                if (errAtt) return callback(errAtt);

                                const previousAttenderScores =
                                  attHistory?.[0]?.transfers?.map(
                                    (t) => t.total_weightage_score,
                                  ) || [];

                                getTransferKpiHistory(pool, period, BMID)
                                  .then((transferHistory) => {
                                    const previousHoTransfers = hoHistory?.[0]?.transfers || [];
                                    const previousAttTransfers = attHistory?.[0]?.transfers || [];
                                    const previousClerkTransfers = transferHistory?.transfers || [];
                                    const previousTransferScores = transferHistory?.all_scores || [];

                                    const allTransfers = [
                                      ...previousHoTransfers,
                                      ...previousAttTransfers,
                                      ...previousClerkTransfers,
                                    ];

                                    let isTransferClerkOrBm = allTransfers.length > 0;
                                    let finalAvg = 0;

                                    if (isTransferClerkOrBm) {
                                      let sumOfPrevious = 0;

                                      allTransfers.forEach((t) => {
                                        const rawScore = Number(t.total_weightage_score || 0);
                                        const months = Number(t.months || 0);
                                        const proportionateScore = months > 0 ? (rawScore / 12) * months : rawScore;
                                        sumOfPrevious += proportionateScore;
                                      });

                                      const currentScoreExcludingInsurance =
                                        Number(finalScores.deposit?.weightageScore || 0) +
                                        Number(finalScores.loan_gen?.weightageScore || 0) +
                                        Number(finalScores.loan_amulya?.weightageScore || 0) +
                                        Number(finalScores.recovery?.weightageScore || 0) +
                                        Number(finalScores.audit?.weightageScore || 0);

                                      const averageExcludingInsurance = sumOfPrevious + currentScoreExcludingInsurance;
                                      const insuranceScore = Number(finalScores.insurance?.weightageScore || 0);
                                      finalAvg = averageExcludingInsurance + insuranceScore;

                                      finalScores.originalTotal = Number((currentScoreExcludingInsurance + insuranceScore).toFixed(2));
                                    } else {
                                      const allScores = [
                                        ...previousHoScores,
                                        ...previousAttenderScores,
                                        ...previousTransferScores,
                                        totalWeightageScore,
                                      ];

                                      finalAvg =
                                        allScores.length > 0
                                          ? allScores.reduce((a, b) => a + b, 0) /
                                          allScores.length
                                          : 0;

                                      finalScores.originalTotal = totalWeightageScore;
                                    }

                                    finalScores.total = finalAvg;

                                    return callback(null, {
                                      ...finalScores,
                                      totalMonthsWorked: totalMonths,
                                      previousHoScores,
                                      previousAttenderScores,
                                      previousTransferScores,
                                      finalAverageScore: finalAvg,
                                    });
                                  })
                                  .catch((errTransfer) =>
                                    callback(errTransfer),
                                  );
                              },
                            );
                          },
                        );
                      });
                    },
                  );
                },
              );
            },
          );
        },
      );
    },
  );
}
//attender score
async function getBranchAttendersScores(period) {
  if (!period) {
    throw new Error("period is required");
  }

  const attenderKpis = await new Promise((resolve, reject) => {
    pool.query(
      `
          SELECT 
            k.kpi_name,
            r.id AS role_kpi_mapping_id,
            r.weightage

          FROM role_kpi_mapping r

          JOIN kpi_master k
            ON r.kpi_id = k.id

          WHERE UPPER(r.role)='ATTENDER'
          `,

      (err, rows) => {
        if (err) {
          return reject(err);
        }

        resolve(rows || []);
      },
    );
  });

  if (!attenderKpis.length) {
    return [];
  }

  const users = await new Promise((resolve, reject) => {
    pool.query(
      `
          SELECT 
            id,
            name,
            branch_id,
            hod_id,
            role

          FROM users

          WHERE period = ?
          AND UPPER(role)='ATTENDER'
          `,
      [period],

      (err, rows) => {
        if (err) {
          return reject(err);
        }

        resolve(rows || []);
      },
    );
  });

  if (!users.length) {
    return [];
  }

  const userIds = users.map((u) => u.id);

  const userEntries = await new Promise((resolve, reject) => {
    pool.query(
      `
          SELECT 
            user_id,
            role_kpi_mapping_id,
            SUM(value) AS total

          FROM user_kpi_entry

          WHERE period=?
          AND user_id IN (?)

          GROUP BY
            user_id,
            role_kpi_mapping_id
          `,
      [period, userIds],

      (err, rows) => {
        if (err) {
          return reject(err);
        }

        resolve(rows || []);
      },
    );
  });

  const insuranceRows = await new Promise((resolve, reject) => {
    pool.query(
      `
          SELECT 
            employee_id,
            SUM(value) AS total

          FROM entries

          WHERE kpi='insurance'
          AND period=?
          AND employee_id IN (?)

          GROUP BY employee_id
          `,
      [period, userIds],

      (err, rows) => {
        if (err) {
          return reject(err);
        }

        resolve(rows || []);
      },
    );
  });

  const entryMap = {};

  userEntries.forEach((r) => {
    if (!entryMap[r.user_id]) {
      entryMap[r.user_id] = {};
    }

    entryMap[r.user_id][r.role_kpi_mapping_id] = Number(r.total || 0);
  });

  const insuranceMap = {};

  insuranceRows.forEach((r) => {
    insuranceMap[r.employee_id] = Number(r.total || 0);
  });

  const response = [];

  for (const user of users) {
    const userKpis = entryMap[user.id] || {};

    const insuranceValue = insuranceMap[user.id] || 0;

    const finalKpis = {};

    let totalScore = 0;

    for (const kpi of attenderKpis) {
      let achieved = 0;

      let target = kpi.weightage;

      if (!kpi.kpi_name.toLowerCase().includes("insurance")) {
        achieved = userKpis[kpi.role_kpi_mapping_id] || 0;
      }

      if (kpi.kpi_name.toLowerCase().includes("insurance")) {
        achieved = insuranceValue;

        target = 40000;
      }

      let score = 0;

      if (achieved > 0) {
        const ratio = achieved / target;

        if (ratio <= 1) {
          score = ratio * 10;
        } else if (ratio < 1.25) {
          score = 10;
        } else {
          score = 12.5;
        }
      }

      const weightageScore = (score * kpi.weightage) / 100;

      finalKpis[kpi.kpi_name] = {
        target,

        achieved,

        weightage: kpi.weightage,

        score,

        weightageScore,
      };

      totalScore += weightageScore;
    }

    response.push({
      staffId: user.id,

      staffName: user.name,

      total: Number(totalScore.toFixed(2)),

      kpis: finalKpis,
    });
  }

  return response;
}
//helper function for get all users
const bmUserScoreCache = new Map();

function getAllUser(pool, period, cb) {
  const startYear = parseInt(period.substring(0, 4));

  const startDate = `${startYear}-04-01`;
  const endDate = `${startYear + 1}-03-31`;

  const query = `
    SELECT 
        u.id, 
        u.username, 
        u.name, 
        u.role,
        u.branch_id, 
        u.hod_id,
        b.name AS branch_name,
        u.transfer_date,

        CASE 
            WHEN u.transfer_date >= ?
             AND u.transfer_date < ?
            THEN 1 
            ELSE 0 
        END AS transfer_flag

    FROM users u
    LEFT JOIN branches b ON u.branch_id = b.code AND b.period = ?
    WHERE u.role IN (
        "BM","Clerk","HO_STAFF","GM",
        "AGM","DGM","AGM_IT","AGM_AUDIT","AGM_INSURANCE",
        "Attender"
    )
    AND (u.resign IS NULL OR u.resign != 1) AND u.period = ? AND u.resign = 0
  `;

  pool.query(query, [startDate, endDate, period, period], cb);
}
function getAllUsers(pool, period, cb) {
  pool.query(
    `
    SELECT u.id, u.username, u.name, u.role,
           u.branch_id, u.hod_id,
           b.name AS branch_name
    FROM users u
    LEFT JOIN branches b ON u.branch_id = b.code AND b.period = ? 
    WHERE u.role IN (
      "BM","Clerk","HO_STAFF","GM",
      "AGM","DGM","AGM_IT","AGM_AUDIT","AGM_INSURANCE",
      "Attender"
    ) AND u.period = ? and u.resign=0
    `,
    [period, period],
    cb,
  );
}
//give the BM Data only form this api
performanceMasterRouter.post("/usersBM", async (req, res) => {
  const { period } = req.body;

  getAllUser(
    pool,
    period,

    async (err, users) => {
      if (err) {
        return res.status(500).json({
          error: "Failed to load users",
        });
      }

      const list = users.filter((u) => u.role === "BM");

      try {
        // NEW BM FUNCTION
        // RETURNS ALL BRANCHES
        const allBmScores = await calculateBMScores(String(period));

        const result = await Promise.all(
          list.map(async (u) => {
            const branchId = Number(u.branch_id);

            let score;

            // TRANSFER BM
            if (u.transfer_flag === 1) {
              const scoreTransfer = await new Promise((resolve, reject) => {
                getTransferBmScores(
                  pool,
                  period,
                  branchId,

                  (err, data) => {
                    if (err) {
                      return reject(err);
                    }

                    resolve(data);
                  },
                );
              });

              score = scoreTransfer
                ? scoreTransfer
                : await calculateBMScoresFortrasfer(String(period), branchId);
            }

            // NORMAL BM
            else {
              // FILTER ONLY CURRENT BRANCH
              score = allBmScores?.[branchId];
            }

            return {
              ...u,

              bmTotalScore: score?.total || 0,
            };
          }),
        );

        res.json({
          users: result,
        });
      } catch (error) {
        console.error(error);

        res.status(500).json({
          error: "Failed to calculate scores",
        });
      }
    },
  );
});

//give the clerk Data of 1/4
performanceMasterRouter.post("/usersClerk/part1", async (req, res) => {
  const { period } = req.body;

  getAllUsers(
    pool,
    period,

    async (err, users) => {
      if (err) {
        return res.status(500).json({
          error: "Failed to load users",
        });
      }

      const list = users.filter((u) => u.role === "Clerk");

      const quarter = Math.ceil(list.length);

      const part = list.slice(0, quarter);

      try {
        // =========================
        // ALL CLERK SCORES
        // =========================
        const allScores = await calculateStaffScoresCb(period);

        const result = await Promise.all(
          part.map(async (u) => {
            try {
              const clerkScore = allScores?.[u.id];

              return {
                ...u,

                bmTotalScore: clerkScore?.total ?? 0,
              };
            } catch {
              return {
                ...u,

                bmTotalScore: 0,
              };
            }
          }),
        );

        res.json({
          totalClerks: list.length,

          currentPartCount: result.length,

          users: result,

          part: 1,
        });
      } catch (err) {
        console.error(err);

        res.status(500).json({
          error: "Failed to calculate scores",
        });
      }
    },
  );
});

//give the clerk Data of 1/2
// =========================
// PART 2
// =========================
performanceMasterRouter.post("/usersClerk/part2", async (req, res) => {
  const { period } = req.body;

  getAllUsers(
    pool,
    period,

    async (err, users) => {
      if (err) {
        return res.status(500).json({
          error: "Failed to load users",
        });
      }

      try {
        const list = users.filter((u) => u.role === "Clerk");

        const quarter = Math.ceil(list.length / 4);

        const part = list.slice(quarter, quarter * 2);

        // NEW FUNCTION
        const allScores = await calculateStaffScoresCb(period);

        const result = part.map((u) => {
          const clerkScore = allScores?.[u.id];

          return {
            ...u,

            bmTotalScore: clerkScore?.total ?? 0,
          };
        });

        res.json({
          totalClerks: list.length,

          currentPartCount: result.length,

          users: result,

          part: 2,
        });
      } catch (error) {
        console.error(error);

        res.status(500).json({
          error: "Failed to calculate scores",
        });
      }
    },
  );
});

// =========================
// PART 3
// =========================
performanceMasterRouter.post("/usersClerk/part3", async (req, res) => {
  const { period } = req.body;

  getAllUsers(
    pool,
    period,

    async (err, users) => {
      if (err) {
        return res.status(500).json({
          error: "Failed to load users",
        });
      }

      try {
        const list = users.filter((u) => u.role === "Clerk");

        const quarter = Math.ceil(list.length / 4);

        const part = list.slice(quarter * 2, quarter * 3);

        // NEW FUNCTION
        const allScores = await calculateStaffScoresCb(period);

        const result = part.map((u) => {
          const clerkScore = allScores?.[u.id];

          return {
            ...u,

            bmTotalScore: clerkScore?.total ?? 0,
          };
        });

        res.json({
          totalClerks: list.length,

          currentPartCount: result.length,

          users: result,

          part: 3,
        });
      } catch (error) {
        console.error(error);

        res.status(500).json({
          error: "Failed to calculate scores",
        });
      }
    },
  );
});

// =========================
// PART 4
// =========================
performanceMasterRouter.post("/usersClerk/part4", async (req, res) => {
  const { period } = req.body;

  getAllUsers(
    pool,
    period,

    async (err, users) => {
      if (err) {
        return res.status(500).json({
          error: "Failed to load users",
        });
      }

      try {
        const list = users.filter((u) => u.role === "Clerk");

        const quarter = Math.ceil(list.length / 4);

        const part = list.slice(quarter * 3);

        // NEW FUNCTION
        const allScores = await calculateStaffScoresCb(period);

        const result = part.map((u) => {
          const clerkScore = allScores?.[u.id];

          return {
            ...u,

            bmTotalScore: clerkScore?.total ?? 0,
          };
        });

        res.json({
          totalClerks: list.length,

          currentPartCount: result.length,

          users: result,

          part: 4,
        });
      } catch (error) {
        console.error(error);

        res.status(500).json({
          error: "Failed to calculate scores",
        });
      }
    },
  );
});
//get all HO_STAFF Score
performanceMasterRouter.post("/usersHOStaff", async (req, res) => {
  const { period } = req.body;

  getAllUsers(
    pool,
    period,

    async (err, users) => {
      if (err) {
        return res.status(500).json({
          error: "Failed to load users",
        });
      }

      try {
        const list = users.filter((u) => u.role === "HO_STAFF");

        const allScores = await calculateSpecificAllStaffScoresCb(
          String(period),
          "HO_STAFF",
        );

        const result = list.map((u) => {
          const hoStaffScore = allScores?.[u.id];

          return {
            ...u,

            bmTotalScore: hoStaffScore?.total ?? 0,
          };
        });

        res.json({
          totalHOStaff: list.length,

          users: result,
        });
      } catch (error) {
        console.error(error);

        res.status(500).json({
          error: "Failed to calculate scores",
        });
      }
    },
  );
});
//get all Attender Score
performanceMasterRouter.post("/usersAttender", async (req, res) => {
  const { period } = req.body;

  getAllUsers(
    pool,
    period,

    async (err, users) => {
      if (err) {
        return res.status(500).json({
          error: "Failed to load users",
        });
      }

      try {
        const list = users.filter((u) => u.role === "Attender");

        const attenders = await getBranchAttendersScores(
          String(period),
          null,
          null,
        );

        const attenderMap = {};

        attenders.forEach((a) => {
          attenderMap[a.staffId] = a;
        });

        const result = list.map((u) => {
          try {
            const current = attenderMap[u.id];

            return {
              ...u,

              bmTotalScore: current?.total ?? 0,
            };
          } catch {
            return {
              ...u,

              bmTotalScore: 0,
            };
          }
        });

        res.json({
          totalAttenders: list.length,

          users: result,
        });
      } catch (err) {
        console.error(err);

        res.status(500).json({
          error: "Failed to calculate scores",
        });
      }
    },
  );
});
//get all AGM/DGM/GM Score
performanceMasterRouter.post("/usersAgmGm", async (req, res) => {
  const { period } = req.body;

  getAllUsers(
    pool,
    period,

    async (err, users) => {
      if (err) {
        return res.status(500).json({
          error: "Failed to load users",
        });
      }

      try {
        const agmUsers = users.filter((u) =>
          ["AGM", "DGM", "AGM_IT", "AGM_AUDIT", "AGM_INSURANCE"].includes(
            u.role,
          ),
        );

        const gmUser = users.find((u) => u.role === "GM") || null;

        // 1. Pre-calculate and cache BM scores
        await calculateBMScores(period);

        // 2. Pre-calculate and cache staff scores
        const agmUserIds = agmUsers.map((u) => u.id);
        const staffIds = users
          .filter((u) => u.hod_id && agmUserIds.includes(u.hod_id))
          .map((u) => u.id);

        if (staffIds.length > 0) {
          const staffScoresBatchMap = await calculateStaffScoresBatch(
            period,
            staffIds,
            "HO_STAFF",
          );
          for (const [id, score] of Object.entries(staffScoresBatchMap)) {
            hodScoreCache.set(`${period}_${id}`, score);
          }
        }

        // 3. Process all HOD users in parallel
        const agmResults = await Promise.all(
          agmUsers.map(async (agm) => {
            try {
              const cacheKey = `${period}_${agm.id}_${agm.role}`;

              if (agmScoreCache.has(cacheKey)) {
                const cached = agmScoreCache.get(cacheKey);
                return {
                  ...agm,
                  bmTotalScore: cached?.total || 0,
                };
              }

              const scoreData = await calculateHodAllScores(
                pool,
                period,
                agm.id,
                agm.role,
                calculateStaffScores,
                calculateBMScores,
              );

              agmScoreCache.set(cacheKey, scoreData);

              return {
                ...agm,
                bmTotalScore: scoreData?.total || 0,
              };
            } catch (err) {
              console.error(err);
              return {
                ...agm,
                bmTotalScore: 0,
              };
            }
          }),
        );

        const agmScores = agmResults.map((r) => r.bmTotalScore);

        const results = [...agmResults];

        if (gmUser && agmScores.length) {
          const per = 100 / agmScores.length;

          const gmScore = agmScores.reduce(
            (sum, a) => sum + (a * per) / 100,

            0,
          );

          results.push({
            ...gmUser,

            bmTotalScore: Number(gmScore.toFixed(2)),
          });
        }

        res.json({
          totalUsers: results.length,

          users: results,
        });
      } catch (error) {
        console.error(error);

        res.status(500).json({
          error: "Failed to calculate scores",
        });
      }
    },
  );
});
//function for get single ho_staff history code
export function getHoStaffTransferHistory(pool, period, ho_staff_id, callback) {
  const role = "HO_STAFF";

  const staffQuery = `
    SELECT id, name, resign
    FROM users
    WHERE id = ? AND period = ?
  `;

  pool.query(staffQuery, [ho_staff_id, period], (err0, staffRows) => {
    if (err0 || !staffRows.length) {
      return callback("Staff fetch failed");
    }

    const staff = staffRows[0];

    const kpiWeightageQuery = `
      SELECT km.kpi_name, rkm.weightage
      FROM role_kpi_mapping rkm
      JOIN kpi_master km ON km.id = rkm.kpi_id
      WHERE rkm.role = ? AND rkm.deleted_at IS NULL
    `;

    pool.query(kpiWeightageQuery, [role], (err, kpiWeightage) => {
      if (err) {
        return callback("Weightage fetch failed");
      }

      const transferQuery = `
        SELECT 
        ho.*, 
        u.name AS hod_name, 
        s.name AS old_hod_name
    FROM ho_staff_transfer ho
    LEFT JOIN users u 
        ON ho.hod_id = u.id 
        AND u.period COLLATE utf8mb4_unicode_ci = ?
    LEFT JOIN users s 
        ON ho.old_hod_id = s.id 
        AND s.period COLLATE utf8mb4_unicode_ci = ?
    WHERE ho.staff_id =?
      AND ho.period = ?
    ORDER BY ho.transfer_date ASC;
          `;

      pool.query(
        transferQuery,
        [period, period, ho_staff_id, period],
        (err2, rows) => {
          if (err2) {
            return callback("Transfer fetch failed");
          }

          const transfers = [];
          const branch_avg_kpi = {};
          let totalMonths = 0;
          let counter = {};

          const getFinancialYearStart = (p) => {
            const startYear = parseInt(p.split("-")[0], 10);
            return new Date(startYear, 3, 1); // April 1
          };
          const monthDiffstart = (d1, d2) => {
            return Math.max(
              0,
              (d2.getFullYear() - d1.getFullYear()) * 12 +
              (d2.getMonth() - d1.getMonth())
            );
          };

          const fyStart = getFinancialYearStart(period);
          let lastDate = fyStart;

          let allTotals = [];

          rows.forEach((t) => {
            const achievedMap = {
              "Alloted Work": Number(t.Alloted_Work) || 0,
              "Discipline & Time Management":
                Number(t["Discipline_&_Time_Management"]) || 0,
              "General Work Performance":
                Number(t.General_Work_Performance) || 0,
              "Branch Communication": Number(t.Branch_Communication) || 0,
            };

            let total = 0;
            const scores = {};

            kpiWeightage.forEach((row) => {
              const { kpi_name, weightage } = row;
              if (kpi_name === "Insurance") return;

              const achieved = achievedMap[kpi_name] || 0;
              const ratio = achieved / weightage;

              let score = 0;
              if (ratio <= 1) score = ratio * 10;
              else if (ratio < 1.25) score = 10;
              else score = 12.5;

              const weightageScore = (score * weightage) / 100;
              total += weightageScore;

              scores[kpi_name] = {
                achieved,
                weightage,
                score: Number(score.toFixed(2)),
                weightageScore: Number(weightageScore.toFixed(2)),
              };
            });

            const transferDate = new Date(t.transfer_date);
            const months = Math.max(1, monthDiffstart(lastDate, transferDate));
            lastDate = transferDate;

            const branch = t.old_hod_name || t.old_designation || "HO_STAFF";

            counter[branch] = (counter[branch] || 0) + 1;
            const uniqueKey = `${branch}_${counter[branch]}`;

            branch_avg_kpi[uniqueKey] = {
              avg_kpi: Number(total.toFixed(2)),
              months: months,
            };

            totalMonths += months;
            allTotals.push(total);

            transfers.push({
              ...scores,
              total_weightage_score: Number(total.toFixed(2)),
              transfer_date: t.transfer_date,
              hod_name: t.hod_name,
              old_hod_name: t.old_hod_name,
              old_designation: t.old_designation,
              new_designation: t.new_designation,
              months: months,
            });
          });

          let avg_kpi = 0;
          if (allTotals.length > 0) {
            avg_kpi = allTotals.reduce((a, b) => a + b, 0) / allTotals.length;
          }

          const response = [
            {
              staff_id: staff.id,
              name: staff.name,
              period,
              resigned: staff.resign,
              transfers,
              branch_avg_kpi,
              total_months: totalMonths,
              avg_kpi: Number(avg_kpi.toFixed(2)),
            },
          ];

          callback(null, response);
        },
      );
    });
  });
}
//function for get single attender history code
export function getAttenderTransferHistory(pool, period, staff_id, callback) {
  const role = "Attender";

  const staffQuery = `
    SELECT id, name, resign
    FROM users
    WHERE id = ? AND period = ?
  `;

  pool.query(staffQuery, [staff_id, period], (err0, staffRows) => {
    if (err0 || !staffRows.length) {
      return callback("Staff fetch failed");
    }

    const staff = staffRows[0];

    const kpiWeightageQuery = `
      SELECT km.kpi_name, rkm.weightage
      FROM role_kpi_mapping rkm
      JOIN kpi_master km ON km.id = rkm.kpi_id
      WHERE rkm.role = ? AND rkm.deleted_at IS NULL
    `;

    pool.query(kpiWeightageQuery, [role], (err, kpiWeightage) => {
      if (err) {
        return callback("Weightage fetch failed");
      }

      const transferQuery = `
       SELECT 
    ho.*, 
    u.name AS hod_name, 
    s.name AS old_hod_name,
    b1.name AS new_branch,
    b2.name AS old_branch

FROM attender_transfer ho

LEFT JOIN users u 
    ON ho.hod_id = u.hod_id COLLATE utf8mb4_unicode_ci
    AND u.period COLLATE utf8mb4_unicode_ci = ?

LEFT JOIN users s 
    ON ho.old_hod_id = s.hod_id COLLATE utf8mb4_unicode_ci
    AND s.period COLLATE utf8mb4_unicode_ci = ?

LEFT JOIN branches b1 
    ON ho.branch_id COLLATE utf8mb4_unicode_ci = b1.code
    AND b1.period COLLATE utf8mb4_unicode_ci = ?

LEFT JOIN branches b2  
    ON ho.old_branch_id COLLATE utf8mb4_unicode_ci = b2.code
    AND b2.period COLLATE utf8mb4_unicode_ci = ?

WHERE ho.staff_id = ?
AND ho.period COLLATE utf8mb4_unicode_ci = ?

ORDER BY ho.transfer_date ASC
      `;

      pool.query(
        transferQuery,
        [period, period, period, period, staff_id, period],
        (err2, rows) => {
          if (err2) {
            return callback("Transfer fetch failed");
          }

          const transfers = [];
          const branch_avg_kpi = {};
          let totalMonths = 0;
          let counter = {};

          const getFinancialYearStart = (p) => {
            const startYear = parseInt(p.split("-")[0], 10);
            return new Date(startYear, 3, 1); // April 1
          };
          const monthDiffstart = (d1, d2) => {
            return Math.max(
              0,
              (d2.getFullYear() - d1.getFullYear()) * 12 +
              (d2.getMonth() - d1.getMonth())
            );
          };

          const fyStart = getFinancialYearStart(period);
          let lastDate = fyStart;

          let allTotals = [];

          rows.forEach((t) => {
            const achievedMap = {
              Cleanliness: Number(t.Cleanliness) || 0,
              "Attitude, Behavior & Discipline":
                Number(t["Attitude_Behavior_&_Discipline"]) || 0,
            };

            let total = 0;
            const scores = {};

            kpiWeightage.forEach((row) => {
              const { kpi_name, weightage } = row;
              if (kpi_name === "Insurance Target") return;

              const achieved = achievedMap[kpi_name] || 0;

              const ratio = achieved / weightage;

              let score = 0;
              if (ratio <= 1) score = ratio * 10;
              else if (ratio < 1.25) score = 10;
              else score = 12.5;

              const weightageScore = (score * weightage) / 100;
              total += weightageScore;

              scores[kpi_name] = {
                achieved,
                weightage,
                score: Number(score.toFixed(2)),
                weightageScore: Number(weightageScore.toFixed(2)),
              };
            });

            const transferDate = new Date(t.transfer_date);
            const months = Math.max(1, monthDiffstart(lastDate, transferDate));
            lastDate = transferDate;

            const branch = t.old_hod_name || t.old_branch || "UNKNOWN";

            counter[branch] = (counter[branch] || 0) + 1;
            const uniqueKey = `${branch}_${counter[branch]}`;

            branch_avg_kpi[uniqueKey] = {
              avg_kpi: Number(total.toFixed(2)),
              months: months,
            };

            totalMonths += months;
            allTotals.push(total);

            transfers.push({
              ...scores,
              total_weightage_score: Number(total.toFixed(2)),
              transfer_date: t.transfer_date,
              hod_name: t.hod_name,
              old_hod_name: t.old_hod_name,
              new_branch_name: t.new_branch,
              old_branch_name: t.old_branch,
              old_designation: t.old_designation,
              new_designation: t.new_designation,
              months: months,
            });
          });

          let avg_kpi = 0;
          if (allTotals.length > 0) {
            avg_kpi = allTotals.reduce((a, b) => a + b, 0) / allTotals.length;
          }

          const response = [
            {
              staff_id: staff.id,
              name: staff.name,
              period,
              resigned: staff.resign,
              transfers,
              branch_avg_kpi,
              total_months: totalMonths,
              avg_kpi: Number(avg_kpi.toFixed(2)),
            },
          ];

          callback(null, response);
        },
      );
    });
  });
}

//ho staff transfer history with kpi scores
performanceMasterRouter.get("/ho_staff_transfer_history", (req, res) => {
  const { period, ho_staff_id } = req.query;
  const role = "HO_STAFF";

  if (!period || !ho_staff_id) {
    return res.status(400).json({
      error: "period, ho_staff_id are required",
    });
  }

  const staffQuery = `
    SELECT id, name, resign,resign_date
    FROM users
    WHERE id = ? AND period = ?
  `;

  pool.query(staffQuery, [ho_staff_id, period], (err0, staffRows) => {
    if (err0 || !staffRows.length) {
      return res.status(500).json({ error: "Staff fetch failed" });
    }

    const staff = staffRows[0];

    const kpiWeightageQuery = `
      SELECT km.kpi_name, rkm.weightage
      FROM role_kpi_mapping rkm
      JOIN kpi_master km ON km.id = rkm.kpi_id
      WHERE rkm.role = ? AND rkm.deleted_at IS NULL
    `;

    pool.query(kpiWeightageQuery, [role], (err, kpiWeightage) => {
      if (err) {
        return res.status(500).json({ error: "Weightage fetch failed" });
      }

      const transferQuery = `
     SELECT 
    ho.*, 
    u.name AS hod_name, 
    s.name AS old_hod_name
FROM ho_staff_transfer ho
LEFT JOIN users u 
    ON ho.hod_id = u.id 
    AND u.period COLLATE utf8mb4_unicode_ci = ?
LEFT JOIN users s 
    ON ho.old_hod_id = s.id 
    AND s.period COLLATE utf8mb4_unicode_ci = ?
WHERE ho.staff_id = ?
  AND ho.period =   ?
ORDER BY ho.transfer_date ASC
      `;

      pool.query(
        transferQuery,
        [period, period, ho_staff_id, period],
        (err2, rows) => {
          if (err2) {
            return res.status(500).json({ error: "Transfer fetch failed" });
          }

          const transfers = [];
          const branch_avg_kpi = {};
          let totalMonths = 0;
          let counter = {};

          const getFinancialYearStart = (p) => {
            const startYear = parseInt(p.split("-")[0], 10);
            return new Date(startYear, 3, 1); // April 1
          };
          const monthDiffstart = (d1, d2) => {
            return Math.max(
              0,
              (d2.getFullYear() - d1.getFullYear()) * 12 +
              (d2.getMonth() - d1.getMonth())
            );
          };

          const fyStart = getFinancialYearStart(period);
          let lastDate = fyStart;

          rows.forEach((t) => {
            const achievedMap = {
              "Alloted Work": Number(t.Alloted_Work) || 0,
              "Discipline & Time Management":
                Number(t["Discipline_&_Time_Management"]) || 0,
              "General Work Performance":
                Number(t.General_Work_Performance) || 0,
              "Branch Communication": Number(t.Branch_Communication) || 0,
            };

            let total = 0;
            const scores = {};

            kpiWeightage.forEach((row) => {
              const { kpi_name, weightage } = row;
              if (kpi_name === "Insurance") return;

              const achieved = achievedMap[kpi_name] || 0;
              const ratio = achieved / weightage;

              let score = 0;
              if (ratio <= 1) score = ratio * 10;
              else if (ratio < 1.25) score = 10;
              else score = 12.5;

              const weightageScore = (score * weightage) / 100;
              total += weightageScore;

              scores[kpi_name] = {
                achieved,
                weightage,
                score: Number(score.toFixed(2)),
                weightageScore: Number(weightageScore.toFixed(2)),
              };
            });

            const transferDate = new Date(t.transfer_date);
            const months = Math.max(1, monthDiffstart(lastDate, transferDate));
            lastDate = transferDate;

            const branch = t.old_hod_name || t.old_designation || "HO_STAFF";

            counter[branch] = (counter[branch] || 0) + 1;
            const uniqueKey = `${branch}_${counter[branch]}`;

            branch_avg_kpi[uniqueKey] = {
              avg_kpi: Number(total.toFixed(2)),
              months: months,
            };

            totalMonths += months;

            transfers.push({
              ...scores,
              total_weightage_score: Number(total.toFixed(2)),
              transfer_date: t.transfer_date,
              hod_name: t.hod_name,
              old_hod_name: t.old_hod_name,
              old_designation: t.old_designation,
              new_designation: t.new_designation,
              months: months,
            });
          });

          const response = [
            {
              staff_id: staff.id,
              name: staff.name,
              period,
              resigned: staff.resign,
              resign_date: staff.resign_date,
              transfers,
              branch_avg_kpi,
              total_months: totalMonths,
            },
          ];

          return res.json(response);
        },
      );
    });
  });
});

//departmentwise report
performanceMasterRouter.post(
  "/getAllBranchesScoreSectionsWise",
  async (req, res) => {
    const { period, department } = req.body;

    if (!period) {
      return res.status(400).json({
        error: "period is required",
      });
    }

    try {
      const branchReportData = {};

      const branches = await new Promise((resolve, reject) => {
        pool.query(
          `
              SELECT 
                code,
                name

              FROM branches

              WHERE period = ?
              `,
          [period],

          (err, rows) => {
            if (err) {
              return reject(err);
            }

            resolve(rows || []);
          },
        );
      });

      const allBranchScores = await calculateBMScores(period);

      const bmUsers = await new Promise((resolve, reject) => {
        pool.query(
          `
              SELECT 
                PF_NO,
                name,
                branch_id

              FROM users

              WHERE role='BM'
              AND period = ?
              `,
          [period],

          (err, rows) => {
            if (err) {
              return reject(err);
            }

            resolve(rows || []);
          },
        );
      });

      const bmMap = {};

      bmUsers.forEach((bm) => {
        bmMap[bm.branch_id] = bm;
      });

      const deptKey = String(department || "")
        .trim()
        .toLowerCase();

      const formattedDepartment = department
        ? department.charAt(0) + department.slice(1)
        : null;

      const batchSize = 5;

      const branchesWithScore = [];

      for (let i = 0; i < branches.length; i += batchSize) {
        const batch = branches.slice(i, i + batchSize);

        const batchResults = await Promise.all(
          batch.map(async (branch) => {
            try {
              const cacheKey = `${period}_${branch.code}_${deptKey}`;

              if (branchScoreCache1.has(cacheKey)) {
                return {
                  ...branch,

                  ...branchScoreCache1.get(cacheKey),
                };
              }

              const bm = bmMap[branch.code];

              const branchScore = allBranchScores?.[branch.code] || {};

              const matchedKey = Object.keys(branchScore).find(
                (key) => key.toLowerCase() === deptKey,
              );

              const result = {
                bmId: bm?.PF_NO ?? null,

                bmName: bm?.name ?? null,

                department: formattedDepartment,

                departmentData: matchedKey ? branchScore[matchedKey] : null,
              };

              branchScoreCache1.set(cacheKey, result);

              return {
                ...branch,

                ...result,
              };
            } catch (err) {
              console.error(`BM score failed for branch ${branch.code}`, err);

              return {
                ...branch,

                bmId: null,

                bmName: null,

                department: formattedDepartment,

                departmentData: null,
              };
            }
          }),
        );

        branchesWithScore.push(...batchResults);
      }

      branchReportData.totalBranches = branchesWithScore;

      branchReportData.totalBranchesCount = branchesWithScore.length;

      res.json(branchReportData);
    } catch (err) {
      console.error(err);

      res.status(500).json({
        error: "Failed to load branch report data",
      });
    }
  },
);

//Attender transfer history wothb this kpis
performanceMasterRouter.get("/attender_transfer_history", (req, res) => {
  const { period, staff_id } = req.query;
  const role = "Attender";

  if (!period || !staff_id) {
    return res.status(400).json({
      error: "period, staff_id are required",
    });
  }

  const staffQuery = `
    SELECT id, name, resign,resign_date
    FROM users
    WHERE id = ? AND period = ?
  `;

  pool.query(staffQuery, [staff_id, period], (err0, staffRows) => {
    if (err0 || !staffRows.length) {
      return res.status(500).json({ error: "Staff fetch failed" });
    }

    const staff = staffRows[0];

    const kpiWeightageQuery = `
      SELECT km.kpi_name, rkm.weightage
      FROM role_kpi_mapping rkm
      JOIN kpi_master km ON km.id = rkm.kpi_id
      WHERE rkm.role = ? AND rkm.deleted_at IS NULL
    `;

    pool.query(kpiWeightageQuery, [role], (err, kpiWeightage) => {
      if (err) {
        return res.status(500).json({ error: "Weightage fetch failed" });
      }

      const transferQuery = `
            SELECT 
    ho.*, 
    u.name AS hod_name, 
    s.name AS old_hod_name,
    b1.name AS new_branch,
    b2.name AS old_branch

FROM attender_transfer ho

LEFT JOIN users u 
    ON ho.hod_id = u.hod_id COLLATE utf8mb4_unicode_ci
    AND u.period COLLATE utf8mb4_unicode_ci = ?

LEFT JOIN users s 
    ON ho.old_hod_id = s.hod_id COLLATE utf8mb4_unicode_ci
    AND s.period COLLATE utf8mb4_unicode_ci = ?

LEFT JOIN branches b1 
    ON ho.branch_id COLLATE utf8mb4_unicode_ci = b1.code
    AND b1.period COLLATE utf8mb4_unicode_ci = ?

LEFT JOIN branches b2  
    ON ho.old_branch_id COLLATE utf8mb4_unicode_ci = b2.code
    AND b2.period COLLATE utf8mb4_unicode_ci = ?

WHERE ho.staff_id = ?
AND ho.period COLLATE utf8mb4_unicode_ci = ?

ORDER BY ho.transfer_date ASC
        `;

      pool.query(
        transferQuery,
        [period, period, period, period, staff_id, period],
        (err2, rows) => {
          if (err2) {
            return res.status(500).json({ error: "Transfer fetch failed" });
          }

          const transfers = [];
          const branch_avg_kpi = {};
          let totalMonths = 0;
          let counter = {};

          const getFinancialYearStart = (p) => {
            const startYear = parseInt(p.split("-")[0], 10);
            return new Date(startYear, 3, 1); // April 1
          };
          const monthDiffstart = (d1, d2) => {
            return Math.max(
              0,
              (d2.getFullYear() - d1.getFullYear()) * 12 +
              (d2.getMonth() - d1.getMonth())
            );
          };

          const fyStart = getFinancialYearStart(period);
          let lastDate = fyStart;

          rows.forEach((t) => {
            const achievedMap = {
              Cleanliness: Number(t.Cleanliness) || 0,
              "Attitude, Behavior & Discipline":
                Number(t["Attitude_Behavior_&_Discipline"]) || 0,
            };

            let total = 0;
            const scores = {};

            kpiWeightage.forEach((row) => {
              const { kpi_name, weightage } = row;
              if (kpi_name === "Insurance Target") return;

              const achieved = achievedMap[kpi_name] || 0;

              const ratio = achieved / weightage;

              let score = 0;
              if (ratio <= 1) score = ratio * 10;
              else if (ratio < 1.25) score = 10;
              else score = 12.5;

              const weightageScore = (score * weightage) / 100;
              total += weightageScore;

              scores[kpi_name] = {
                achieved,
                weightage,
                score: Number(score.toFixed(2)),
                weightageScore: Number(weightageScore.toFixed(2)),
              };
            });

            const transferDate = new Date(t.transfer_date);
            const months = Math.max(1, monthDiffstart(lastDate, transferDate));
            lastDate = transferDate;

            const branch = t.old_hod_name || t.old_branch || "UNKNOWN";

            counter[branch] = (counter[branch] || 0) + 1;
            const uniqueKey = `${branch}_${counter[branch]}`;

            branch_avg_kpi[uniqueKey] = {
              avg_kpi: Number(total.toFixed(2)),
              months: months,
            };

            totalMonths += months;

            transfers.push({
              ...scores,
              total_weightage_score: Number(total.toFixed(2)),
              transfer_date: t.transfer_date,
              hod_name: t.hod_name,
              old_hod_name: t.old_hod_name,
              new_branch_name: t.new_branch,
              old_branch_name: t.old_branch,
              old_designation: t.old_designation,
              new_designation: t.new_designation,
              months: months,
            });
          });

          const response = [
            {
              staff_id: staff.id,
              name: staff.name,
              period,
              resigned: staff.resign,
              resign_date: staff.resign_date,
              transfers,
              branch_avg_kpi,
              total_months: totalMonths,
            },
          ];

          return res.json(response);
        },
      );
    });
  });
});

//get last transfer data according passing peroid
performanceMasterRouter.get("/getLasttransfer", (req, res) => {
  const { period, staff_id } = req.query;

  if (!period) {
    return res.status(400).json({ error: "Period is required" });
  }

  const query = `
    SELECT 
      staff_id,
          old_branch_id,
          new_branch_id,
          period,
          old_designation,
          new_designation
    FROM employee_transfer
    WHERE period = ? AND staff_id = ?
    ORDER BY transfer_date DESC
    LIMIT 1;
  `;

  pool.query(query, [period, staff_id], (err, results) => {
    if (err) {
      console.error("Error fetching last transfer:", err);
      return res
        .status(500)
        .json({ error: "Failed to fetch last transfer data" });
    }

    res.json(results[0] || null);
  });
});
