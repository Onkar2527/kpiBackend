import express from "express";
import pool from "../db.js";
import bcrypt from "bcryptjs";

export const mastersRouter = express.Router();

function parseTransferId(rawId) {
  const str = String(rawId);
  if (str.startsWith("emp_")) {
    return { type: "emp", id: parseInt(str.substring(4), 10) };
  } else if (str.startsWith("ho_")) {
    return { type: "ho", id: parseInt(str.substring(3), 10) };
  } else if (str.startsWith("att_")) {
    return { type: "att", id: parseInt(str.substring(4), 10) };
  }
  return { type: "emp", id: parseInt(str, 10) };
}

// Departments
mastersRouter.get("/departments", (req, res) => {
  pool.query("SELECT * FROM departments", (error, results) => {
    if (error) return res.status(500).json({ error: "Internal server error" });
    res.json(results);
  });
});

mastersRouter.post("/departments", (req, res) => {
  const { name } = req.body;
  pool.getConnection((err, connection) => {
    if (err) return res.status(500).json({ error: "Internal server error" });
    connection.beginTransaction((err) => {
      if (err) {
        connection.release();
        return res.status(500).json({ error: "Internal server error" });
      }
      connection.query(
        "INSERT INTO departments (name) VALUES (?)",
        [name],
        (error, result) => {
          if (error) {
            return connection.rollback(() => {
              connection.release();
              res.status(500).json({ error: "Internal server error" });
            });
          }
          connection.commit((err) => {
            if (err) {
              return connection.rollback(() => {
                connection.release();
                res.status(500).json({ error: "Internal server error" });
              });
            }
            connection.release();
            res.json({ id: result.insertId, name });
          });
        },
      );
    });
  });
});

mastersRouter.put("/departments/:id", (req, res) => {
  const { name } = req.body;
  pool.query(
    "UPDATE departments SET name = ? WHERE id = ?",
    [name, req.params.id],
    (error) => {
      if (error)
        return res.status(500).json({ error: "Internal server error" });
      res.json({ ok: true });
    },
  );
});

mastersRouter.delete("/departments/:id", (req, res) => {
  pool.query(
    "DELETE FROM departments WHERE id = ?",
    [req.params.id],
    (error, result) => {
      if (error)
        return res.status(500).json({ error: "Internal server error" });
      if (result.affectedRows === 0) {
        return res.status(404).json({ error: "Department not found" });
      }
      res.json({ ok: true });
    },
  );
});

// Weightages
mastersRouter.get("/weightages", (req, res) => {
  pool.query("SELECT * FROM weightage", (error, results) => {
    if (error) return res.status(500).json({ error: "Internal server error" });
    res.json(results);
  });
});

mastersRouter.put("/weightages", (req, res) => {
  const { kpi, weightage } = req.body;
  pool.query(
    "UPDATE weightage SET weightage = ? WHERE kpi = ?",
    [weightage, kpi],
    (error) => {
      if (error)
        return res.status(500).json({ error: "Internal server error" });
      res.json({ ok: true });
    },
  );
});

// Users
mastersRouter.post("/users", (req, res, next) => {
  if (req.body.username || req.body.name || req.body.password) {
    return next();
  }
  const { period } = req.body;
  pool.query(
    "SELECT u.id, u.username, u.name, u.role, b.name as branch_name, u.PF_NO, d.name as department_name,u.branch_id,u.hod_id,u.transfer_date,u1.name as hod_name FROM users u left join branches b on u.branch_id=b.code AND b.period = ? left join departments d on d.id=u.department_id left join users u1 on u.hod_id = u1.id WHERE u.resign=0 AND u.period = ? ",
    [period, period], (error, results) => {
      if (error)
        return res.status(500).json({ error: "Internal server error" });
      res.json(results);
    },
  );
});

mastersRouter.post("/users", (req, res) => {
  const {
    username,
    name,
    password,
    role,
    branch_id,
    department_id,
    PF_NO,
    hod_id,
    period
  } = req.body;
  const password_hash = bcrypt.hashSync(password, 10);

  const user = {
    username,
    name,
    password_hash,
    role,
    branch_id,
    department_id,
    PF_NO,
    hod_id,
    period
  };
  pool.getConnection((err, connection) => {
    if (err) return res.status(500).json({ error: "Internal server error" });
    connection.beginTransaction((err) => {
      if (err) {
        connection.release();
        return res.status(500).json({ error: "Internal server error" });
      }
      connection.query("INSERT INTO users SET ?", user, (error) => {
        if (error) {
          return connection.rollback(() => {
            connection.release();
            res.status(500).json({ error: "Internal server error" });
          });
        }
        connection.commit((err) => {
          if (err) {
            return connection.rollback(() => {
              connection.release();
              res.status(500).json({ error: "Internal server error" });
            });
          }
          connection.release();
          res.json(user);
        });
      });
    });
  });
});

mastersRouter.put("/users/:id", (req, res) => {
  const {
    username,
    name,
    role,
    branch_id,
    department_id,
    PF_NO,
    password,
    hod_id, period
  } = req.body;
  const user = {
    username,
    name,
    role,
    branch_id,
    department_id,
    PF_NO,
    hod_id, period
  };
  if (password) {
    user.password_hash = bcrypt.hashSync(password, 10);
  }
  pool.query(
    "UPDATE users SET ? WHERE id = ?",
    [user, req.params.id],
    (error) => {
      if (error)
        return res.status(500).json({ error: "Internal server error" });
      res.json({ ok: true });
    },
  );
});

mastersRouter.post("/users/:id", (req, res) => {
  const { resignedDate, period } = req.body;

  pool.query(
    "UPDATE users SET resign = 1,  resign_date = ?, hod_id = NULL WHERE id = ? AND period = ?",
    [resignedDate, req.params.id, period],
    (error, result) => {
      if (error) {
        console.error("Error updating user:", error);
        return res.status(500).json({ error: "Internal server error" });
      }

      if (result.affectedRows === 0) {
        return res.status(404).json({ error: "User not found" });
      }

      res.json({ ok: true, message: "User marked as resigned" });
    },
  );
});

mastersRouter.get("/users/branch/:branchId/role/:role", (req, res) => {
  const { branchId, role } = req.params;
  pool.query(
    "SELECT id, name, role, branch_id FROM users WHERE branch_id = ? AND role = ?",
    [branchId, role],
    (error, results) => {
      if (error)
        return res.status(500).json({ error: "Internal server error" });
      res.json(results);
    },
  );
});

// Branches
mastersRouter.post("/branches", (req, res, next) => {
  if (req.body.code || req.body.name) {
    return next();
  }
  const { period } = req.body;
  pool.query(
    "SELECT b.*, u.name AS incharge_name FROM branches b left join users u on b.incharge_id=u.id WHERE u.period = ? and b.period = ?",
    [period, period],
    (error, results) => {
      if (error)
        return res.status(500).json({ error: "Internal server error" });
      res.json(results);
    },
  );
});

mastersRouter.post("/branches", (req, res) => {
  const { code, name, incharge_id, period } = req.body;
  const branch = { code, name, incharge_id, period };

  pool.getConnection((err, connection) => {
    if (err) return res.status(500).json({ error: "Internal server error" });
    connection.beginTransaction((err) => {
      if (err) {
        connection.release();
        return res.status(500).json({ error: "Internal server error" });
      }
      connection.query("INSERT INTO branches SET ?", branch, (error) => {
        if (error) {
          return connection.rollback(() => {
            connection.release();
            res.status(500).json({ error: "Internal server error" });
          });
        }
        connection.commit((err) => {
          if (err) {
            return connection.rollback(() => {
              connection.release();
              res.status(500).json({ error: "Internal server error" });
            });
          }
          connection.release();
          res.json(branch);
        });
      });
    });
  });
});

mastersRouter.put("/branches/:id", (req, res) => {
  const { code, name, incharge_id, period } = req.body;
  pool.query(
    "UPDATE branches SET code = ?, name = ?, incharge_id = ?, period = ? WHERE id = ? AND period = ?",
    [code, name, incharge_id, period, req.params.id, period],
    (error) => {
      if (error)
        return res.status(500).json({ error: "Internal server error" });
      res.json({ ok: true });
    },
  );
});

mastersRouter.delete("/branches/:id", (req, res) => {
  pool.query(
    "DELETE FROM branches WHERE id = ?",
    [req.params.id],
    (error, result) => {
      if (error)
        return res.status(500).json({ error: "Internal server error" });
      if (result.affectedRows === 0) {
        return res.status(404).json({ error: "Branch not found" });
      }
      res.json({ ok: true });
    },
  );
});

//staff Transfers
mastersRouter.post("/transfers", (req, res) => {
  const { period } = req.body;
  pool.query(
    `SELECT 
    t.id,
    t.staff_id,
    u.name,
    t.old_branch_id,
    t.new_branch_id,
    b1.name AS old_branch,
    b2.name AS new_branch,
    old_hod.name AS old_hod_name,
    new_hod.name AS new_hod_name,
    t.transfer_date
FROM (
    SELECT 
        CONCAT('att_', id) AS id,
        staff_id,
        old_branch_id,
        branch_id AS new_branch_id,
        old_hod_id,
        hod_id,
        transfer_date
    FROM attender_transfer
    WHERE period = ?

    UNION ALL

    SELECT 
        CONCAT('ho_', id) AS id,
        staff_id,
        NULL AS old_branch_id,
        NULL AS new_branch_id,
        old_hod_id,
        hod_id,
        transfer_date
    FROM ho_staff_transfer
    WHERE period = ?

    UNION ALL

    SELECT 
        CONCAT('emp_', id) AS id,
        staff_id,
        old_branch_id,
        new_branch_id,
        NULL AS old_hod_id,
        NULL AS hod_id,
        transfer_date
    FROM employee_transfer
    WHERE period = ?
) t
JOIN users u 
    ON u.id = t.staff_id AND u.period = ?

LEFT JOIN branches b1 
    ON b1.code COLLATE utf8mb4_unicode_ci = t.old_branch_id COLLATE utf8mb4_unicode_ci
    AND b1.period COLLATE utf8mb4_unicode_ci = u.period COLLATE utf8mb4_unicode_ci

LEFT JOIN branches b2 
    ON b2.code COLLATE utf8mb4_unicode_ci = t.new_branch_id COLLATE utf8mb4_unicode_ci
    AND b2.period COLLATE utf8mb4_unicode_ci = u.period COLLATE utf8mb4_unicode_ci

LEFT JOIN users old_hod 
    ON old_hod.id = t.old_hod_id AND old_hod.period = ?

LEFT JOIN users new_hod 
    ON new_hod.id = t.hod_id AND new_hod.period = ?;`,
    [period, period, period, period, period, period], (error, results) => {
      if (error) {
        console.error(error);
        return res.status(500).json({ error: "Internal server error" });
      }
      res.json(results);
    },
  );
});

mastersRouter.post("/transfers", (req, res) => {
  const {
    staff_id,
    old_branch_id,
    new_branch_id,
    kpi_total,
    period,
    deposit_target,
    deposit_achieved,
    loan_gen_target,
    loan_gen_achieved,
    loan_amulya_target,
    loan_amulya_achieved,
    audit_target,
    audit_achieved,
    recovery_target,
    recovery_achieved,
    insurance_target,
    insurance_achieved,
    old_designation,
    new_designation,
  } = req.body;

  const transfer = {
    staff_id,
    old_branch_id,
    new_branch_id,
    kpi_total,
    period,
    deposit_target,
    deposit_achieved,
    loan_gen_target,
    loan_gen_achieved,
    loan_amulya_target,
    loan_amulya_achieved,
    audit_target,
    audit_achieved,
    recovery_target,
    recovery_achieved,
    insurance_target,
    insurance_achieved,
    old_designation,
    new_designation,
  };

  pool.getConnection((err, connection) => {
    if (err) return res.status(500).json({ error: "Internal server error" });

    connection.beginTransaction((err) => {
      if (err) {
        connection.release();
        return res.status(500).json({ error: "Internal server error" });
      }

      const query = "INSERT INTO employee_transfer SET ?";

      connection.query(query, transfer, (error) => {
        if (error) {
          console.error("Insert error:", error);
          return connection.rollback(() => {
            connection.release();
            res.status(500).json({ error: "Database insert failed" });
          });
        }

        connection.commit((err) => {
          if (err) {
            return connection.rollback(() => {
              connection.release();
              res.status(500).json({ error: "Transaction commit failed" });
            });
          }

          connection.release();
          res.json({
            message: "Transfer added successfully",
            data: transfer,
          });
        });
      });
    });
  });
});

mastersRouter.put("/transfers/:id", (req, res) => {
  const { type, id } = parseTransferId(req.params.id);
  const { staff_id, old_branch_id, new_branch_id, kpi_total } = req.body;

  if (type === "ho") {
    pool.query(
      "UPDATE ho_staff_transfer SET staff_id = ?, kpi_total = ? WHERE id = ?",
      [staff_id, kpi_total, id],
      (error) => {
        if (error) return res.status(500).json({ error: "Internal server error" });
        res.json({ ok: true });
      }
    );
  } else if (type === "att") {
    pool.query(
      "UPDATE attender_transfer SET staff_id = ?, old_branch_id = ?, branch_id = ?, kpi_total = ? WHERE id = ?",
      [staff_id, old_branch_id, new_branch_id, kpi_total, id],
      (error) => {
        if (error) return res.status(500).json({ error: "Internal server error" });
        res.json({ ok: true });
      }
    );
  } else {
    pool.query(
      "UPDATE employee_transfer SET staff_id = ?, old_branch_id = ?, new_branch_id = ?, kpi_total = ? WHERE id = ?",
      [staff_id, old_branch_id, new_branch_id, kpi_total, id],
      (error) => {
        if (error)
          return res.status(500).json({ error: "Internal server error" });
        res.json({ ok: true });
      },
    );
  }
});

mastersRouter.delete("/transfers/:id", (req, res) => {
  const { type, id } = parseTransferId(req.params.id);
  const table = type === "ho" ? "ho_staff_transfer" : type === "att" ? "attender_transfer" : "employee_transfer";

  pool.getConnection((err, connection) => {
    if (err) return res.status(500).json({ error: "DB connection failed" });

    connection.query(
      `SELECT * FROM ${table} WHERE id = ?`,
      [id],
      (errSelect, rows) => {
        if (errSelect) {
          connection.release();
          return res.status(500).json({ error: "Internal server error" });
        }
        if (rows.length === 0) {
          connection.release();
          return res.status(404).json({ error: "Transfer not found" });
        }

        const tr = rows[0];
        let oldBranchId = null;
        let newBranchId = null;

        if (type === "emp") {
          oldBranchId = tr.old_branch_id;
          newBranchId = tr.new_branch_id;
        } else if (type === "att") {
          oldBranchId = tr.old_branch_id;
          newBranchId = tr.branch_id;
        }

        const proceedDelete = (resolvedNewBranchId) => {
          connection.query(
            `DELETE FROM ${table} WHERE id = ?`,
            [id],
            (error, result) => {
              if (error) {
                connection.release();
                return res.status(500).json({ error: "Internal server error" });
              }

              if (table === "employee_transfer") {
                connection.query(
                  "DELETE FROM bm_transfer_target WHERE staff_id = ? AND period = ?",
                  [tr.staff_id, tr.period],
                  () => {
                    connection.release();
                    res.json({
                      ok: true,
                      old_branch_id: oldBranchId,
                      new_branch_id: resolvedNewBranchId
                    });
                  }
                );
              } else {
                connection.release();
                res.json({
                  ok: true,
                  old_branch_id: oldBranchId,
                  new_branch_id: resolvedNewBranchId
                });
              }
            }
          );
        };

        if (type === "ho") {
          // Fetch current branch_id from users table for HO Staff
          connection.query(
            "SELECT branch_id FROM users WHERE id = ? AND period = ?",
            [tr.staff_id, tr.period],
            (errUser, userRows) => {
              if (errUser) {
                connection.release();
                return res.status(500).json({ error: "Internal server error" });
              }
              proceedDelete(userRows[0]?.branch_id || null);
            }
          );
        } else {
          proceedDelete(newBranchId);
        }
      }
    );
  });
});

mastersRouter.post("/revert-transfer/:id", (req, res) => {
  const rawId = req.params.id;
  const { type, id } = parseTransferId(rawId);
  const hasPrefix = String(rawId).startsWith("emp_") || String(rawId).startsWith("ho_") || String(rawId).startsWith("att_");

  pool.getConnection((err, connection) => {
    if (err) return res.status(500).json({ error: "DB connection failed" });

    connection.beginTransaction((err) => {
      if (err) {
        connection.release();
        return res.status(500).json({ error: "Transaction start failed" });
      }

      const rollbackTx = (errorMsg) => {
        connection.rollback(() => {
          connection.release();
          res.status(500).json({ error: errorMsg });
        });
      };

      const revertEmp = () => {
        connection.query(
          "SELECT * FROM employee_transfer WHERE id = ?",
          [id],
          (err, empRows) => {
            if (err) return rollbackTx(err.message);
            if (empRows.length > 0) {
              const tr = empRows[0];
              connection.query(
                "UPDATE users SET branch_id = ?, role = ?, transfered = 0, transfer_date = NULL WHERE id = ? AND period = ?",
                [tr.old_branch_id, tr.old_designation, tr.staff_id, tr.period],
                (errUpdate) => {
                  if (errUpdate) return rollbackTx(errUpdate.message);

                  connection.query(
                    "DELETE FROM employee_transfer WHERE id = ?",
                    [id],
                    (errDelete) => {
                      if (errDelete) return rollbackTx(errDelete.message);

                      connection.query(
                        "DELETE FROM bm_transfer_target WHERE staff_id = ? AND period = ?",
                        [tr.staff_id, tr.period],
                        (errBmDelete) => {
                          if (errBmDelete) return rollbackTx(errBmDelete.message);

                          connection.commit((errCommit) => {
                            if (errCommit) return rollbackTx(errCommit.message);
                            connection.release();
                            return res.json({
                              ok: true,
                              old_branch_id: tr.old_branch_id,
                              new_branch_id: tr.new_branch_id
                            });
                          });
                        }
                      );
                    }
                  );
                }
              );
            } else if (!hasPrefix) {
              revertAtt();
            } else {
              rollbackTx("Transfer not found");
            }
          }
        );
      };

      const revertAtt = () => {
        connection.query(
          "SELECT * FROM attender_transfer WHERE id = ?",
          [id],
          (err, attRows) => {
            if (err) return rollbackTx(err.message);
            if (attRows.length > 0) {
              const tr = attRows[0];
              connection.query(
                "UPDATE users SET branch_id = ?, role = ?, hod_id = ?, transfered = 0, transfer_date = NULL WHERE id = ? AND period = ?",
                [tr.old_branch_id, tr.old_designation, tr.old_hod_id, tr.staff_id, tr.period],
                (errUpdate) => {
                  if (errUpdate) return rollbackTx(errUpdate.message);

                  connection.query(
                    "DELETE FROM attender_transfer WHERE id = ?",
                    [id],
                    (errDelete) => {
                      if (errDelete) return rollbackTx(errDelete.message);

                      connection.commit((errCommit) => {
                        if (errCommit) return rollbackTx(errCommit.message);
                        connection.release();
                        return res.json({
                          ok: true,
                          old_branch_id: tr.old_branch_id,
                          new_branch_id: tr.branch_id
                        });
                      });
                    }
                  );
                }
              );
            } else if (!hasPrefix) {
              revertHo();
            } else {
              rollbackTx("Transfer not found");
            }
          }
        );
      };

      const revertHo = () => {
        connection.query(
          "SELECT * FROM ho_staff_transfer WHERE id = ?",
          [id],
          (err, hoRows) => {
            if (err) return rollbackTx(err.message);
            if (hoRows.length > 0) {
              const tr = hoRows[0];
              connection.query(
                "SELECT branch_id FROM users WHERE id = ? AND period = ?",
                [tr.staff_id, tr.period],
                (errUser, userRows) => {
                  if (errUser) return rollbackTx(errUser.message);
                  const currentBranchId = userRows[0]?.branch_id || null;

                  connection.query(
                    "UPDATE users SET branch_id = NULL, role = ?, hod_id = ?, transfered = 0, transfer_date = NULL WHERE id = ? AND period = ?",
                    [tr.old_designation, tr.old_hod_id, tr.staff_id, tr.period],
                    (errUpdate) => {
                      if (errUpdate) return rollbackTx(errUpdate.message);

                      connection.query(
                        "DELETE FROM ho_staff_transfer WHERE id = ?",
                        [id],
                        (errDelete) => {
                          if (errDelete) return rollbackTx(errDelete.message);

                          connection.commit((errCommit) => {
                            if (errCommit) return rollbackTx(errCommit.message);
                            connection.release();
                            return res.json({
                              ok: true,
                              old_branch_id: null,
                              new_branch_id: currentBranchId
                            });
                          });
                        }
                      );
                    }
                  );
                }
              );
            } else {
              rollbackTx("Transfer not found");
            }
          }
        );
      };

      if (type === "emp") {
        revertEmp();
      } else if (type === "att") {
        revertAtt();
      } else if (type === "ho") {
        revertHo();
      } else {
        rollbackTx("Invalid transfer type");
      }
    });
  });
});

mastersRouter.put("/Transfers_user/:id", (req, res) => {
  const { branch_id, role, hod_id, period } = req.body;
  const user = { branch_id, role, transfered: 1, hod_id };

  pool.query(
    "UPDATE users SET ? WHERE id = ? AND period = ?",
    [user, req.params.id, period],
    (error) => {
      if (error)
        return res.status(500).json({ error: "Internal server error" });
      res.json({ ok: true });
    },
  );
});
mastersRouter.put("/Transfers_date/:id", (req, res) => {
  pool.query(
    "UPDATE users SET transfer_date = NOW() WHERE id = ?",
    [req.params.id],
    (error, result) => {
      if (error) {
        return res.status(500).json({ error: "Internal server error" });
      }

      if (result.affectedRows === 0) {
        return res.status(404).json({ error: "User not found" });
      }

      res.json({ ok: true });
    },
  );
});

mastersRouter.put("/resign_user/:id", (req, res) => {
  const user = { branch_id: "" };

  pool.query(
    "UPDATE users SET ? WHERE id = ?",
    [user, req.params.id],
    (error) => {
      if (error)
        return res.status(500).json({ error: "Internal server error" });
      res.json({ ok: true });
    },
  );
});
mastersRouter.delete("/Transfer_for_delete_allocation", (req, res) => {
  const { user_id } = req.body;
  const user = { user_id };

  pool.query(
    "DELETE FROM allocations WHERE user_id = ?",
    [user_id],
    (error) => {
      if (error)
        return res.status(500).json({ error: "Internal server error" });
      res.json({ ok: true });
    },
  );
});

mastersRouter.delete("/Transfer_for_delete_ho_staff", (req, res) => {
  const { ho_staff_id, branch_id } = req.body;
  const user = { ho_staff_id, branch_id };
  pool.query(
    "DELETE FROM ho_staff_kpi WHERE ho_staff_id = ? AND branch_id = ?",
    [ho_staff_id, branch_id],
    (error) => {
      if (error)
        return res.status(500).json({ error: "Internal server error" });
      res.json({ ok: true });
    },
  );
});

// trasfer-history
mastersRouter.post("/trasfer-history", (req, res) => {
  const { period } = req.body;
  const query = `SELECT 
    e.staff_id,
    s.PF_NO,
    s.name,
    DATE(MIN(e.transfer_date)) AS transfer_date,
    s.resign
FROM (
    SELECT staff_id, transfer_date, period FROM employee_transfer
    UNION ALL
    SELECT staff_id, transfer_date, period FROM ho_staff_transfer
    UNION ALL
    SELECT staff_id, transfer_date, period FROM attender_transfer
) e
JOIN users s 
    ON s.id = e.staff_id
WHERE e.period = ? AND s.period = ?
GROUP BY e.staff_id, DATE(e.transfer_date)
ORDER BY DATE(MIN(e.transfer_date));`;
  pool.query(query, [period, period], (error, results) => {
    if (error) return res.status(500).json({ error: "Internal server error" });
    res.json(results);
  });
});

//This function help to get strat Date and End Data of Year 
const getFinancialYearStart = (period) => {
  const startYear = parseInt(period.split("-")[0], 10);
  return new Date(startYear, 3, 1); // April 1
};

// get the transfer-Kpi-history of indivisual staff
mastersRouter.post("/transfer-Kpi-history", (req, res) => {
  const { period, staff_id } = req.body;

  const query = `
   SELECT 
    e.*,
    u.name AS staff_name,
    b.name AS branch_name,
    bi.name AS new_branch_name,
    u.resign as resigned,
    u.resign_date as resign_date
FROM 
    employee_transfer e
    INNER JOIN users u ON u.id = e.staff_id
    INNER JOIN branches b 
        ON b.code COLLATE utf8mb4_unicode_ci = 
           e.old_branch_id COLLATE utf8mb4_unicode_ci
           AND b.period COLLATE utf8mb4_unicode_ci = e.period COLLATE utf8mb4_unicode_ci
    LEFT JOIN branches bi 
        ON bi.code COLLATE utf8mb4_unicode_ci = 
           e.new_branch_id COLLATE utf8mb4_unicode_ci       
           AND bi.period COLLATE utf8mb4_unicode_ci = e.period COLLATE utf8mb4_unicode_ci
WHERE 
    e.period COLLATE utf8mb4_unicode_ci = ? AND u.period COLLATE utf8mb4_unicode_ci = ?
    AND e.staff_id = ?
ORDER BY 
    e.staff_id,
    e.transfer_date ASC;
  `;

  pool.query(query, [period, period, staff_id], (err, transfers) => {
    if (err) return res.status(500).json({ error: "Internal server error" });
    if (transfers.length === 0) return res.json([]);

    const weightageQuery = `SELECT kpi, weightage FROM weightage`;

    pool.query(weightageQuery, (err, weightages) => {
      if (err)
        return res.status(500).json({ error: "Error fetching weightage" });

      const weightageMap = {};
      weightages.forEach((w) => {
        weightageMap[w.kpi] = w.weightage;
      });

      pool.query(
        "SELECT branch_id, kpi, amount FROM previous_period_data_staffwise WHERE period = ? AND employee_id = ? AND deleted_at IS NULL",
        [period, staff_id],
        (errPrev, prevRows) => {
          if (errPrev)
            return res.status(500).json({ error: "Error fetching staffwise baseline" });

          const baselineMap = {};
          prevRows.forEach((row) => {
            baselineMap[`${row.branch_id}_${row.kpi}`] = row.amount || 0;
          });

          const calculateScore = (kpi, achieved, target) => {
            let outOf10;
            if (!target || Number(target) === 0) return 0;

            const ratio = achieved / target;
            const auditRatio = kpi === "audit" ? ratio : 0;
            const recoveryRatio = kpi === "recovery" ? ratio : 0;

            switch (kpi) {
              case "deposit":
              case "loan_gen":
              case "loan_amulya":
                if (ratio <= 1) {
                  outOf10 = ratio * 10;
                } else if (ratio > 1 && ratio < 1.25) {
                  outOf10 = 10;
                } else if (
                  ratio >= 1.25 &&
                  auditRatio >= 0.75 &&
                  recoveryRatio >= 0.75
                ) {
                  outOf10 = 12.5;
                } else {
                  outOf10 = 10;
                }
                break;

              case "recovery":
              case "audit":
                outOf10 = ratio <= 1 ? ratio * 10 : 12.5;
                break;

              default:
                outOf10 = 0;
            }

            return Math.max(0, Math.min(12.5, isNaN(outOf10) ? 0 : outOf10));
          };

          const monthDiffstart = (d1, d2) => {
            return Math.max(
              0,
              (d2.getFullYear() - d1.getFullYear()) * 12 +
              (d2.getMonth() - d1.getMonth())
            );
          };

          const staffResult = {
            staff_id: transfers[0].staff_id,
            name: transfers[0].staff_name,
            period: transfers[0].period,
            resigned: transfers[0].resigned,
            resign_date: transfers[0].resign_date,
            transfers: [],
            branch_avg_kpi: {},
            total_months: 0,
          };

          const fyStart = getFinancialYearStart(period);
          const branchTransferDates = {};
          const branchWiseKpi = {};
          let lastDate = fyStart;

          transfers.forEach((t) => {
            const branchScores = {};
            let totalWeightageScore = 0;

            const transferDate = new Date(t.transfer_date);
            const months = Math.max(1, monthDiffstart(lastDate, transferDate));
            lastDate = transferDate;

            const kpis = [
              {
                key: "deposit",
                achieved: t.deposit_achieved,
                target: t.deposit_target,
              },
              {
                key: "loan_gen",
                achieved: t.loan_gen_achieved,
                target: t.loan_gen_target,
              },
              {
                key: "loan_amulya",
                achieved: t.loan_amulya_achieved,
                target: t.loan_amulya_target,
              },
              {
                key: "recovery",
                achieved: t.recovery_achieved,
                target: t.recovery_target,
              },
              { key: "audit", achieved: t.audit_achieved, target: t.audit_target },
            ];

            kpis.forEach((row) => {
              if (row.target == null) return;

              const baseline = ["deposit", "loan_gen", "loan_amulya"].includes(row.key)
                ? (Number(t[`${row.key}_baseline`]) || baselineMap[`${t.old_branch_id}_${row.key}`] || 0)
                : 0;

              // Read baseline and target directly without month factor scaling
              const scaledBaseline = Number(baseline);
              const scaledTarget = Number(row.target || 0);

              // Read achievement directly
              const achievedValue = Number(row.achieved || 0);

              const isBaselineOnly =
                ["deposit", "loan_gen", "loan_amulya"].includes(row.key) &&
                Number(baseline) > 0 &&
                achievedValue <= scaledBaseline;

              const score = isBaselineOnly
                ? 0
                : calculateScore(row.key, achievedValue, scaledTarget);

              const weightage = weightageMap[row.key] || 0;
              const weightageScore = isBaselineOnly ? 0 : (score * weightage) / 100;

              branchScores[row.key] = {
                achieved: isBaselineOnly ? 0 : Number(achievedValue.toFixed(2)),
                previousBalance: Number(scaledBaseline.toFixed(2)),
                newTarget: Number(scaledTarget.toFixed(2)),
                totalTarget: Number((scaledTarget + scaledBaseline).toFixed(2)),
                target: Number(scaledTarget.toFixed(2)),
                score,
                weightage,
                weightageScore: isNaN(weightageScore) ? 0 : weightageScore,
              };

              totalWeightageScore += branchScores[row.key].weightageScore;
            });

            const branch = t.branch_name;
            if (!branchTransferDates[branch]) branchTransferDates[branch] = [];
            branchTransferDates[branch].push(new Date(t.transfer_date));

            if (!branchWiseKpi[branch])
              branchWiseKpi[branch] = { total: 0, count: 0 };
            branchWiseKpi[branch].total += totalWeightageScore;
            branchWiseKpi[branch].count += 1;

            staffResult.transfers.push({
              transfer_date: t.transfer_date,
              old_designation: t.old_designation,
              new_designation: t.new_designation,
              old_branch_name: t.branch_name,
              new_branch_name: t.new_branch_name,
              total_weightage_score: totalWeightageScore,
              months: months,
              ...branchScores,
            });
          });

          let totalMonthsWorked = 0;
          let branchCounter = {};

          staffResult.transfers.forEach((t) => {
            const branch = t.old_branch_name || "UNKNOWN";

            branchCounter[branch] = (branchCounter[branch] || 0) + 1;
            const key = `${branch}#${branchCounter[branch]}`;

            staffResult.branch_avg_kpi[key] = {
              avg_kpi: t.total_weightage_score,
              months: t.months,
              new_branch_name: t.new_branch_name,
            };

            totalMonthsWorked += t.months;
          });

          staffResult.total_months = totalMonthsWorked;

          res.json([staffResult]);
        }
      );
    });
  });
});


//password change API Logic
mastersRouter.post("/verifyPassword", (req, res) => {
  const { userId, oldPassword, period } = req.body;

  pool.query(
    "SELECT * FROM users WHERE id = ? AND period = ?",
    [userId, period],
    (error, results) => {
      if (error) {
        console.error(error);
        return res.status(500).json({
          error: "Internal server error"
        });
      }

      if (results.length === 0) {
        return res.status(404).json({
          error: "User not found"
        });
      }

      const user = results[0];

      const enteredPassword = String(oldPassword);
      const storedPassword = String(user.password_hash);

      let isValidPassword = false;

      // Check bcrypt password
      if (
        storedPassword.startsWith("$2a$") ||
        storedPassword.startsWith("$2b$") ||
        storedPassword.startsWith("$2y$")
      ) {
        isValidPassword = bcrypt.compareSync(
          enteredPassword,
          storedPassword
        );
      } else {
        // Plain-text / numeric password
        isValidPassword = enteredPassword === storedPassword;
      }

      if (!isValidPassword) {
        return res.status(401).json({
          error: "Invalid old password"
        });
      }

      return res.json({
        ok: true
      });
    }
  );
});

mastersRouter.put("/changePassword/:id", (req, res) => {
  const { newPassword } = req.body;
  const password_hash = bcrypt.hashSync(newPassword, 10);
  pool.query(
    "UPDATE users SET password_hash = ? WHERE id = ?",
    [password_hash, req.params.id],
    (error) => {
      if (error)
        return res.status(500).json({ error: "Internal server error" });
      res.json({ ok: true });
    },
  );
});

//admin panel entries management logic
mastersRouter.put("/updateentries/:id", (req, res) => {
  const { kpi, account_no, value, date } = req.body;

  const updateQuery = `
      UPDATE entries 
      SET 
        kpi = ?, 
        account_no = ?, 
        value = ?, 
        date = ?,
        modified_at = ?
      WHERE id = ?
  `;

  pool.query(
    updateQuery,
    [kpi, account_no, value, date, new Date(), req.params.id],
    (error) => {
      if (error) {
        console.error("Update error:", error);
        return res.status(500).json({ error: "Internal server error" });
      }

      const selectQuery = "SELECT * FROM entries WHERE id = ?";

      pool.query(selectQuery, [req.params.id], (error, result) => {
        if (error) {
          console.error("Select error:", error);
          return res.status(500).json({ error: "Internal server error" });
        }

        res.json({
          ok: true,
          updatedEntry: result[0],
        });
      });
    },
  );
});

//update emplyee trasfer table for resign employee report
mastersRouter.post("/update_employee_transfer", (req, res) => {
  const { period, branchId, userId } = req.body;

  // 1. Fetch resigned KPI allocations
  pool.query(
    `SELECT kpi, amount 
     FROM allocations 
     WHERE period = ? AND branch_id = ? AND user_id = ? AND state = 'resigned'`,
    [period, branchId, userId],
    (err, rows) => {
      if (err)
        return res
          .status(500)
          .json({ error: "Database error 1", details: err });

      if (rows.length === 0) {
        return res
          .status(404)
          .json({ error: "No resigned allocations found for this user" });
      }

      // KPI → employee_transfer columns mapping
      const mapping = {
        deposit: "deposit_target",
        loan_gen: "loan_gen_target",
        loan_amulya: "loan_amulya_target",
        recovery: "recovery_target",
        audit: "audit_target",
      };

      const updateData = {};
      rows.forEach((row) => {
        if (mapping[row.kpi]) {
          updateData[mapping[row.kpi]] = row.amount;
        }
      });

      if (Object.keys(updateData).length === 0) {
        return res.status(400).json({ error: "No valid KPI data to update" });
      }

      // 2. Check entry in employee_transfer table
      pool.query(
        "SELECT id FROM employee_transfer WHERE period = ? AND old_branch_id = ? AND staff_id = ?",
        [period, branchId, userId],
        (err, result) => {
          if (err)
            return res
              .status(500)
              .json({ error: "Database error 2", details: err });

          if (result.length === 0) {
            return res.status(404).json({
              error:
                "No employee_transfer record found for this user. Update not possible.",
            });
          }

          const transferId = result[0].id;

          // 3. Update employee_transfer
          pool.query(
            "UPDATE employee_transfer SET ? WHERE id = ?",
            [updateData, transferId],
            (err) => {
              if (err)
                return res
                  .status(500)
                  .json({ error: "Database error 3", details: err });

              // 4. After employee_transfer update → update users.branch_id=''
              const userUpdate = { branch_id: "" };

              pool.query(
                "UPDATE users SET ? WHERE id = ? AND period = ?",
                [userUpdate, userId, period],
                (err) => {
                  if (err)
                    return res
                      .status(500)
                      .json({ error: "Database error 4", details: err });

                  return res.json({
                    success: true,
                    message:
                      "Transfer updated and user branch cleared successfully",
                    updatedFields: updateData,
                  });
                },
              );
            },
          );
        },
      );
    },
  );
});

//update emplyee trasfer table for Transfered employee report
mastersRouter.post("/update_employee_transfer_Transfered", (req, res) => {
  const { period, branchId, userId } = req.body;

  // 1. Fetch resigned KPI allocations
  pool.query(
    `SELECT kpi, amount 
     FROM allocations 
     WHERE period = ? AND branch_id = ? AND user_id = ? AND state = 'Transfered'`,
    [period, branchId, userId],
    (err, rows) => {
      if (err)
        return res
          .status(500)
          .json({ error: "Database error 1", details: err });

      if (rows.length === 0) {
        return res
          .status(404)
          .json({ error: "No transfer allocations found for this user" });
      }

      // KPI → employee_transfer columns mapping
      const mapping = {
        deposit: "deposit_target",
        loan_gen: "loan_gen_target",
        loan_amulya: "loan_amulya_target",
        recovery: "recovery_target",
        audit: "audit_target",
      };

      const updateData = {};
      rows.forEach((row) => {
        if (mapping[row.kpi]) {
          updateData[mapping[row.kpi]] = row.amount;
        }
      });

      if (Object.keys(updateData).length === 0) {
        return res.status(400).json({ error: "No valid KPI data to update" });
      }

      // 2. Check entry in employee_transfer table
      pool.query(
        "SELECT id FROM employee_transfer WHERE period = ? AND old_branch_id = ? AND staff_id = ?",
        [period, branchId, userId],
        (err, result) => {
          if (err)
            return res
              .status(500)
              .json({ error: "Database error 2", details: err });

          if (result.length === 0) {
            return res.status(404).json({
              error:
                "No employee_transfer record found for this user. Update not possible.",
            });
          }

          const transferId = result[0].id;

          // 3. Update employee_transfer
          pool.query(
            "UPDATE employee_transfer SET ? WHERE id = ?",
            [updateData, transferId],
            (err) => {
              if (err)
                return res
                  .status(500)
                  .json({ error: "Database error 3", details: err });

              const userUpdate = { branch_id: "" };

              pool.query(
                "UPDATE users SET ? WHERE id = ? AND period = ?",
                [userUpdate, userId, period],
                (err) => {
                  if (err)
                    return res
                      .status(500)
                      .json({ error: "Database error 4", details: err });

                  return res.json({
                    success: true,
                    message:
                      "Transfer updated and user branch cleared successfully",
                    updatedFields: updateData,
                  });
                },
              );
            },
          );
        },
      );
    },
  );
});

//get All Higher Authority
mastersRouter.post("/get-AGM", (req, res) => {
  const { period } = req.body;
  pool.query(
    ` select id , username,name from users where role in ('AGM','DGM','AGM_AUDIT','AGM_INSURANCE','AGM_IT','GM') and period = ?`,
    [period], (error, results) => {
      if (error)
        return res.status(500).json({ error: "Internal server error" });
      res.json(results);
    },
  );
});



